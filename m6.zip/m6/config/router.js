const fs = require('fs')
const config = require('./index')
const utils = require('./utils')

const result = []

const readdir = (pagesPath, fileLevel = []) => {
  const _dir = utils.resolveDir(pagesPath)

  fs.readdirSync(_dir).forEach(fileName => {
    const state = fs.lstatSync(_dir + '/' + fileName)
    if (state.isDirectory()) {
      readdir(pagesPath + '/' + fileName, fileLevel.concat(fileName))
    } else if (/vue/.test(fileName)) {
      result.push(fileLevel.concat(fileName))
    }
  })
}

readdir(config.router.pagesPath)

fs.writeFile(utils.resolveDir(config.router.configName), JSON.stringify(result), function (err) {
  if (!err) {
    console.log('===============')
    console.log('router.json 配置完毕')
    console.log('===============')
  }
})
