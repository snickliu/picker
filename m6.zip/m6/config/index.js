var argv = require('yargs').argv

let publicPath
if (argv.deploy === 'release') {
  publicPath = 'https://sp-res-wap.dgstaticresources.net/fusion/m6/'
} else {
  publicPath = '/fusion/m6/'
}

module.exports = {
  // 打包路径配置
  deploy: {
    publicPath
  },

  // 全局scss文件
  globalScss: [
    './src/assets/styles/var.scss',
    './src/assets/styles/mixin.scss',
    './src/assets/styles/common.scss'
  ],

  // alias 简写
  alias: {
    'SRC': '../src',
    'ASSETS': '../src/assets',
    'STYLES': '../src/assets/styles',
    'IMAGES': '../src/assets/images',
    'COMMON': '../src/common',
    'COMPONENTS': '../src/common/components',
    'LIB': '../src/common/lib',
    'UI': '../src/common/ui',
    'UTILS': '../src/common/utils'
  },

  // 路由自动化配置
  router: {
    pagesPath: '../src/pages',
    configName: '../src/router/router.json'
  }
}
