import Vue from 'vue'
import Vuex from 'vuex'
import modules from './modules'
import createPersistedState from 'vuex-persistedstate'
import _cloneDeep from 'lodash/cloneDeep'
import _forEach from 'lodash/forEach'
import localStorageFilter from './localStorageFilter'
import _set from 'lodash/set'
import PKG from '../../package.json'

const versionKey = `${PKG.name}_version`
const localVersion = localStorage.getItem(versionKey)
if (localVersion !== PKG.version) {
  localStorage.removeItem(PKG.name)
  localStorage.setItem(versionKey, PKG.version)
}

const persistedStateOptions = {
  key: `${PKG.name}_main`,
  setState (key, state, storage) {
    const _state = _cloneDeep(state)
    _forEach(localStorageFilter, (value, key) => {
      _set(_state, key, value)
    })
    return storage.setItem(key, JSON.stringify(_state))
  }
}

Vue.use(Vuex)

const store = new Vuex.Store({
  plugins: [createPersistedState(persistedStateOptions)],
  strict: true,
  modules
})
export default store
