import types from '../mutation-types'

export default {
  state: {
    apiData: {}
  },

  getters: {
    apiStore: state => state.apiData
  },

  mutations: {
    [types.ADD_APIDATA] (state, { apiName, key, data }) {
      if (!apiName) {
        return
      }
      if (key) {
        if (!state.apiData[apiName]) {
          state.apiData[apiName] = {}
        }
        state.apiData[apiName][key] = data
      } else {
        state.apiData[apiName] = data
      }
    }
  }
}
