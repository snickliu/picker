import types from '../mutation-types'

export default {
  state: {
    numberMap: {},
    siteConfig: {},
    lastPageRecord: {},
    commentData: {}
  },

  getters: {
    siteConfig: state => state.siteConfig,
    numberMap: state => state.numberMap,
    lastPageRecord: state => state.lastPageRecord,
    commentData: state => state.commentData
  },

  mutations: {
    [types.UPDATE_NUMBERMAP] (state, numberMap) {
      state.numberMap = numberMap
    },

    [types.UPDATE_SITECONFIG] (state, siteConfig) {
      state.siteConfig = siteConfig
    },

    [types.UPDATE_LASTPAGERECORD] (state, { curPageName, lastPageName }) {
      state.lastPageRecord = {}
      if (!arguments.length === 1) {
        return
      }

      if (!state.lastPageRecord[curPageName]) {
        state.lastPageRecord[curPageName] = lastPageName
      }
    },

    [types.UPDATE_COMMENTDATA] (state, { type, param, data }) {
      state.commentData[type] = {
        param,
        data
      }
    }
  },
  actions: {
    clearSiteConfig ({ commit }) {
      commit(types.UPDATE_SITECONFIG, {})
    }
  }
}
