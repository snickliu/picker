import user from './user'
import apiStore from './apiStore'
import base from './base'

export default {
  user,
  apiStore,
  base
}
