import types from '../mutation-types'

export default {
  state: {
    accessToken: null,
    identity: null,
    info: {}
  },

  getters: {
    accessToken: state => state.accessToken,
    identity: state => state.identity,
    userInfo: state => state.info,
    isLogin: state => !!state.info.userName
  },

  mutations: {
    [types.UPDATE_ACCESSTOKEN] (state, token) {
      state.accessToken = token
    },

    [types.UPDATE_INDENTITY] (state, identity) {
      state.identity = identity
    },

    [types.UPDATE_USERINFO] (state, info) {
      state.info = info
    }
  },
  actions: {
    clearUserInfo ({ commit }) {
      commit(types.UPDATE_USERINFO, {})
      commit(types.UPDATE_ACCESSTOKEN, null)
      commit(types.UPDATE_INDENTITY, null)
    }
  }
}
