import store from 'SRC/store'

const updateTitle = (router) => {
  router.beforeResolve((to, from, next) => {
    try {
      const title = to.matched[to.matched.length - 1].components.default.title || ''
      const appName = store.getters.appName
      document.title = appName ? appName + title : title
      next()
    } catch (err) {
      next()
    }
  })
}

const checkLogin = (router) => {
  router.beforeResolve((to, from, next) => {
    try {
      const meta = to.matched[to.matched.length - 1].components.default.meta
      if (!store.getters.isLogin && meta.needLogin) {
        next({
          name: 'home'
        })
      } else {
        next()
      }
    } catch (err) {
      next()
    }
  })
}

const setLastPage = (router) => {
  router.beforeResolve((to, from, next) => {
    let curPageName = to.name
    let lastPageName = from.name
    if (!(/auth/.test(curPageName) && /auth/.test(lastPageName))) {
      store.commit('UPDATE_LASTPAGERECORD', {
        curPageName,
        lastPageName
      })
    }
    next()
  })
}

const watch = (router) => {
  checkLogin(router)
  updateTitle(router)
  setLastPage(router)
}

export default {
  watch
}
