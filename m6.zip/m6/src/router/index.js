import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const routerConfig = require('./router.json')

const initRoutes = (fileList) => {
  const _list = []
  fileList.forEach(fileLevel => {
    if (fileLevel.length < 2) {
      return
    }
    const filePath = fileLevel.join('/')

    const file = fileLevel.pop()
    let fileName = file.split('.')[0]
    fileName = fileName.substring(0, 1).toLowerCase() + fileName.substring(1)

    let keepAlive = false
    if (/-k/.test(fileName)) {
      fileName = fileName.slice(0, -2)
      keepAlive = true
    }

    const isIndex = fileName.toLowerCase() === 'index'

    if (isIndex) {
      if (fileLevel.length === 1) {
        initHomePage(fileLevel, keepAlive)
        return
      }
    } else {
      fileLevel = fileLevel.concat(fileName)
    }

    const routerPath = '/' + fileLevel.join('/')
    const routerName = fileLevel.join('_')

    _list.push({
      path: routerPath,
      name: routerName,
      meta: {
        keepAlive
      },
      component: (resolve) => {
        import(`../pages/${filePath}`).then((module) => {
          resolve(module)
        })
      }
    })
  })

  return _list
}

const initHomePage = (fileLevel, keepAlive) => {
  const name = fileLevel[0]

  homePageRoutes.push({
    path: '/' + name,
    name,
    meta: {
      keepAlive
    },
    component: (resolve) => {
      import(`../pages/${name}/${keepAlive ? 'Index-k' : 'Index'}.vue`).then((module) => {
        resolve(module)
      })
    }
  })
}

const homePageRoutes = []
const routes = initRoutes(routerConfig)

const routeArr = [
  ...routes,
  {
    path: '/app',
    name: 'app',
    component: (resolve) => {
      import('../pages/HomePage').then((module) => {
        resolve(module)
      })
    },
    children: homePageRoutes
  },
  {
    path: '*',
    redirect: '/home'
  }
]

export default new Router({
  linkActiveClass: 'active',
  routes: routeArr
})
