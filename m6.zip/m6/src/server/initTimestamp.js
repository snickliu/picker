/*
  获取服务器时间戳
*/
import axios from 'axios'
import config from './config'
import api from './api'
import store from 'SRC/store'
import mutationType from 'SRC/store/mutation-types'

export default () => {
  const _now = Date.now()
  return new Promise((resolve, reject) => {
    axios.post(api.get('timestamp'), { timeout: config.timeout }).then(res => {
      try {
        store.commit(mutationType.UPDATE_TIMESTAMPDELAY, res.data.data.timestamp * 1000 - _now)
        resolve()
      } catch (err) {
        reject(res)
      }
    }).catch(err => {
      reject(err)
    })
  })
}
