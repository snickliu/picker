export default {
  numberMap: '/api/data/content',
  prizeNumber: '/api/LotteryTrend/prizeNumber',
  statiData: '/api/data/statistics',
  paperList: '/api/Paper/paperList',
  picList: '/api/Paper/picList',
  defaultAvatar: '/api/User/getDefaultAvatar',
  login: 'api/User/signin',
  reg: '/api/User/signUp',
  logout: '/api/User/singOut',
  modifyPwd: '/api/User/modifyPassword',
  modifyAvatar: '/api/User/modifyAvatar',
  linkList: '/api/Link/linkList',

  postDetail: '/api/Post/postDetail',
  postList: '/api/Post/postList',
  downPost: '/api/Post/downPost',
  upPost: '/api/Post/upPost',
  commentList: '/api/Comment/getCommentList',
  addComment: '/api/Comment/addComment',
  likeComment: '/api/Comment/upComment',
  delComment: '/api/Comment/deleteComment',
  // Forum Post
  forumPost: '/api/Post/addPost',
  // Last Post
  getLastPost: '/api/Post/getLastPost',
  // 首页配置
  homeConfiguration: '/api/index/homeConfiguration',
  // 站点配置
  siteConfig: 'api/index/siteConfig',
  // 帖子详情页广告
  advertising: 'api/post/advertising',
  // 首页广告位
  dialogConfig: 'api/index/dialogConfig'
}
