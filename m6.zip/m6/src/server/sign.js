import md5 from 'md5'

export default (body, timestamp, nonce) => {
  const data = {
    ...body,
    timestamp,
    nonce: nonce
  }
  let sign = ''
  Object.keys(data).sort().forEach(key => {
    const content = data[key]
    if (typeof content !== 'undefined' && content !== '') {
      let value = typeof content === 'object' ? JSON.stringify(content) : content
      sign += `&${key}=${value}`
    }
  })
  sign = sign.substr(1)
  return md5(sign + process.env.VUE_APP_SING_KEY)
}
