import axios from 'axios'
import api from './api'
import store from '../store'
import initTimestamp from './initTimestamp'
import signData from './sign'
import config from './config'

import mutationTypes from 'SRC/store/mutation-types'
import random from 'UTILS/random'
import errorHandler from './errorHandler'
import eventHub from 'LIB/eventHub'

const doAction = ({ apiName, res, req, action }) => {
  if (/store/.test(action)) {
    const key = action.split('?')[1]
    store.commit(mutationTypes.ADD_APIDATA, {
      apiName,
      key: req[key],
      data: res
    })
  } else if (mutationTypes[action]) {
    store.commit(mutationTypes[action], {
      apiName,
      data: res
    })
  }
}
// 解决预览问题
const getQueryString = (value, name) => {
  let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i')
  let r = value.substr(1).match(reg)
  if (r != null) {
    return unescape(r[2])
  }
}
const fetch = (apiName, data = {}, headerConfig = {}) => {
  return new Promise((resolve, reject) => {
    let _url = api[apiName]

    if (!apiName || !_url) {
      reject(new Error('请输入请求正确的地址'))
      return false
    }

    // url后面跟随一些action
    const urlInfo = _url.split('#')
    _url = urlInfo[0]
    const action = urlInfo[1]
    if (/store/.test(action)) {
      const actionArr = action.split('?')
      const key = actionArr[1]
      let storeData
      if (key && store.getters.apiStore[apiName]) {
        storeData = store.getters.apiStore[apiName][data[key]]
      } else {
        storeData = store.getters.apiStore[apiName]
      }
      if (storeData) {
        resolve(storeData)
        return
      }
    }

    const timestamp = Date.now() + store.getters.timeStampDelay
    const nonce = timestamp + random.string('-xxyxxyxx')
    const sign = signData(data, timestamp, nonce)
    // 读取地址栏参数 begin
    const url = location.href
    const i = url.indexOf('?')
    const isPreview = getQueryString(url.substr(i), 'isPreview')
    // end
    const accessToken = store.getters.accessToken
    const identity = store.getters.identity

    const headers = {
      ...headerConfig,
      Sign: sign
    }

    if (accessToken) {
      headers['Auth-Token'] = accessToken
    }

    if (identity) {
      headers['Auth-Identity'] = identity
    }

    axios({
      timeout: config['timeout'],
      withCredentials: config['withCredentials'],
      url: _url,
      method: 'post',
      headers,
      data: {
        ...data,
        timestamp,
        nonce,
        isPreview
      }
    }).then(res => {
      const authToken = res.headers['auth-token']

      if (res.status === config.successCode) {
        try {
          if (res.data[config.errorCodeKey] === config.successCode) {
            if (!authToken) {
              doAction({
                action,
                req: data,
                apiName,
                res: res.data.data
              })
              resolve(res.data.data)
            }

            if (res.headers['auth-identity']) {
              store.commit(mutationTypes.UPDATE_INDENTITY, res.headers['auth-identity'])
            }
          } else {
            errorHandler(res.data, reject)
          }
        } catch (err) {
          reject(err)
        }

        if (authToken) {
          doAction({
            action,
            apiName,
            req: data,
            res: res.data.data
          })
          store.commit(mutationTypes.UPDATE_ACCESSTOKEN, authToken)
          resolve(res.data.data)
        }
      } else {
        reject(res)
      }
    }).catch(err => {
      if (/timeout/.test(err)) {
        eventHub.publish('networkTimeout')
      }
      reject(err)
    })
  })
}

export default {
  fetch,
  initTimestamp
}
