export default {
  errorCodeKey: 'code',
  withCredentials: true,
  timeout: 7000,
  successCode: 200,

  rsaPublicKey: `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCUtGuwSyE4pkjiDC8tZ/Q5tBLm
whZ+thqkP1/opa0OwOLWkCmcicJ7ozQSw0aNJDR1XocTwCpZnKOcZGLjHOhwE5DG
1jDY1Dzcn/F2mnsxkDnTJox5AvwltAoPV4MAMYs5RIB89UfUTThCkCwLafAQW7bB
RtnYt2R72FSXrHz0cQIDAQAB
-----END PUBLIC KEY-----`
}
