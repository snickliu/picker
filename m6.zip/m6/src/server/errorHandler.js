import store from '../store'
import mutationTypes from '../store/mutation-types'
import eventHub from 'LIB/eventHub'

const loginErrorCodeList = [
  100008, // 用户身份错误，重新登录
  101021, // 需要传入token
  101023, // 用户身份错误，不是正确的正式用户，试玩用户等
  10007, // 用户未登录
  10008, // 用户登录异常
  10009, // 用户账号或密码错误
  10010, // 登录状态已过期，请重新登录
  10011, // 您的账号已在其他地方登录，您已被踢下线
  10012 // 系统已将您退出登录状态，请联系客服
]

const overDue = 101053

export default (data, reject, handler) => {
  if (loginErrorCodeList.indexOf(data.errorcode) > 0) {
    store.commit(mutationTypes.UPDATE_USERINFO, {})
    reject({
      ...data,
      loginError: true
    })
    return
  }

  // 账户余额类的错误
  if (data.errorcode === 103001) {
    reject({
      ...data,
      accountBalanceError: true
    })
    return
  }

  // 试玩账号过期
  if (data.errorcode === overDue) {
    eventHub.publish('guestOverDue')
    reject({
      ...data,
      overDueError: true
    })
    return
  }

  reject(data)
}
