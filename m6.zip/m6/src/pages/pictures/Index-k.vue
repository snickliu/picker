<template>
  <div class="p-pictures">
    <KsHeader title="2018年彩色"/>
    <section class="g-content" ref="scroll">
      <ul class="pic-list" v-if="paperList" ref="wrapper">
        <li class="pic" v-for="item in paperList" :key="item.id" @click="jumpToDetail(item)">
          <BaseImage :defaultSrc="require('IMAGES/default/pic.png')" :imgSrc="item.pic" :showLoading="true"/>
          <p class="title">{{item.title}}</p>
        </li>
      </ul>
      <template v-if="end">
        <p class="end">-- 数据已加载完毕 --</p>
        <SiteFooter/>
      </template>
      <UpArrow/>
    </section>
  </div>
</template>

<script>

export default {
  name: '',

  title: '图库',

  components: {},

  data () {
    return {
      page: 1,
      end: false,
      scrollNode: null,
      paperList: null,
      contentHeight: 0
    }
  },

  created () {
    this.fetchPaperList(this.page)
    this.$nextTick(() => {
      this.scrollNode = this.$refs.scroll
      this.contentHeight = this.scrollNode.getBoundingClientRect().height
    })
  },

  methods: {
    jumpToDetail (item) {
      this.$router.push({
        path: '/pictures/detail',
        query: {
          title: item.title,
          key: item.key,
          type: item.type
        }
      })
    },

    scrollEvent () {
      if (this.contentHeight * 1.5 + this.scrollNode.scrollTop > this.$refs.wrapper.getBoundingClientRect().height) {
        this.fetchPaperList(++this.page)
        this.scrollNode.removeEventListener('scroll', this.scrollEvent)
      }
    },

    fetchPaperList (page) {
      this.$loading.show()
      this.$server.fetch('paperList', {
        page,
        size: 20
      }).then(res => {
        this.$loading.hide()
        this.paperList = (this.paperList || []).concat(res.list)
        if (res.totalPage > page) {
          this.scrollNode.addEventListener('scroll', this.scrollEvent)
        } else {
          this.end = true
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-pictures {
    @extend %g-body;
    padding-bottom: .98rem;
    .g-content {
      @extend %g-scroll;
      .pic-list {
        padding: .14rem;
        .pic {
          position: relative;
          display: inline-block;
          width: 49%;
          height: 2rem;
          margin: .1rem 0;
          border-radius: .1rem;
          overflow: hidden;
          &:nth-child(even) {
            margin-left: 2%;
          }
          .m-base-img {
            height: 100%;
          }
          .title {
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            text-align: center;
            background-color: rgba(0, 0, 0, .6);
            color: $white;
            line-height: .44rem;
            font-size: .28rem;
          }
        }
      }
    }
    .end {
      text-align: center;
      color: $text-assist;
      line-height: .44rem;
    }
  }
</style>
