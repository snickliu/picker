<template>
  <div class="p-picture-detail">
    <KsHeader :title="$route.query.title" leftIcon="arrow-left" rightText="全部" @tapRight="visible = true"/>
    <template v-if="picList">
      <p class="issue c-text">第{{picList[curIndex].period}}期</p>
      <div class="btns">
        <span class="btn" :class="{'c-text c-bd': curIndex > 0}" @click="selIssue('pre')">上一期</span>
        <span class="btn" :class="{'c-text c-bd': curIndex < picList.length - 1}" @click="selIssue('next')">下一期</span>
      </div>
      <section class="g-content">
        <div class="pic">
          <BaseImage
            :defaultSrc="require('IMAGES/default/pic.png')"
            :imgSrc="picList[curIndex].pic"
            :showLoading="true"/>
        </div>
      </section>
    </template>
    <SiteFooter :fixBottom="true"/>

    <Popup v-model="visible" pos="top">
      <KsHeader title="全部" rightIcon="cancel" @tapRight="visible = false"/>
      <section class="issue-list">
        <ul class="list" v-if="picList">
          <li class="item c-bd"
              :class="curIndex === index ? 'active c-bg' : 'c-text'"
              v-for="(item, index) in picList"
              :key="item.id"
              @click="curIndex = index; visible = false">第{{item.period}}期
          </li>
        </ul>
      </section>
    </Popup>
  </div>
</template>

<script>
import Popup from 'COMPONENTS/Popup'

export default {
  name: '',

  title: '图库详情',

  components: {
    Popup
  },

  data () {
    return {
      curIndex: 0,
      curPeriod: 0,
      visible: false,
      picList: null
    }
  },

  created () {
  },

  activated () {
    this.fetchPicList()
  },

  methods: {
    selIssue (action) {
      if (action === 'pre' && this.curIndex !== 0) {
        this.curIndex--
        return
      }

      if (action === 'next' && this.curIndex !== this.picList.length - 1) {
        this.curIndex++
      }
    },

    fetchPicList () {
      this.$loading.show()
      this.$server.fetch('picList', {
        key: this.$route.query.key,
        type: this.$route.query.type
      }).then(res => {
        this.$loading.hide()
        this.picList = res.list
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-picture-detail {
    @extend %g-body;
    background-color: $white;
    .issue {
      font-size: .34rem;
      text-align: center;
      padding-top: .4rem;
    }
    .btns {
      @extend %u-flex-box;
      margin: .4rem 1rem;
      .btn {
        border: 1px solid $text-assist;
        border-radius: .1rem;
        width: 1.6rem;
        line-height: .6rem;
        text-align: center;
        font-size: .3rem;
        color: $text-assist;
      }
    }
    .g-content {
      @extend %g-scroll;
      margin-bottom: 1rem;
      .pic {
        margin: 0 .4rem;
        height: 100%;
        .m-base-img {
          height: 100%;
        }
      }
    }

    .issue-list {
      background-color: $white;
      height: 8.2rem;
      overflow: scroll;
      .list {
        @extend %u-flex-box;
        flex-wrap: wrap;
        justify-content: flex-start;
        padding: .28rem .3rem 0 .3rem;
        .item {
          width: 22%;
          line-height: .6rem;
          text-align: center;
          border: 1px solid;
          border-radius: .1rem;
          margin-right: 4%;
          margin-bottom: .24rem;
          font-size: .28rem;
          &:nth-child(4n) {
            margin-right: 0;
          }
          &.active {
            color: $white;
          }
        }
      }
    }
  }
</style>
