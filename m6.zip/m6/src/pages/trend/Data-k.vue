<template>
  <div class="p-data">
    <KsHeader :title="`${new Date().getFullYear()}年资料大全`" leftIcon="arrow-left"/>

    <div class="g-tab">
      <Tab v-model="tabIndex">
        <TabItem v-for="tab in tabList" :key="tab.key">{{tab.name}}</TabItem>
      </Tab>
    </div>

    <section class="g-content" v-if="tableObj">
      <div class="m-table">
        <div class="line" v-for="item in tableObj[tabList[tabIndex].key]" :key="item.title">
          <div class="title">{{item.title}}</div>
          <div class="ball-box" v-if="tabList[tabIndex].key === 'fowl'">
            <span class="item" v-for="num in item.list" :key="num">{{num}}</span>
          </div>
          <div class="ball-box" v-else>
            <b :class="`ball ball-${numberMap[num].color}`" v-for="num in item.list" :key="num">{{num}}</b>
          </div>
        </div>
      </div>
      <SiteFooter/>
    </section>
  </div>
</template>

<script>
import { Tab, TabItem } from 'COMPONENTS/Tab'
import { mapGetters } from 'vuex'
import fowlData from 'UTILS/data/fowl'

export default {
  name: '',

  title: '资料',

  components: {
    Tab,
    TabItem
  },

  data () {
    return {
      tabIndex: 0,
      tabList: [{
        name: '色波',
        key: 'color',
        titleList: ['红波', '蓝波', '绿波', '单', '双'],
        titleValue: ['red', 'blue', 'green', 'odd', 'even']
      }, {
        name: '生肖',
        key: 'zodiac',
        titleList: ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪']
      }, {
        name: '五行',
        key: 'wuXing',
        titleList: ['金', '木', '水', '火', '土']
      }, {
        name: '家禽',
        key: 'fowl',
        titleList: []
      }]
    }
  },

  computed: {
    ...mapGetters({
      numberMap: 'numberMap'
    }),

    tableObj () {
      const tableObj = {}
      this.tabList.forEach(tab => {
        const tabKey = tab.key
        const tableList = []

        const curTitleValue = tab.titleValue || tab.titleList

        curTitleValue.forEach((title, index) => {
          const list = []
          Object.keys(this.numberMap).forEach(num => {
            if ((this.numberMap[num][tabKey] === title) ||
              (title === 'odd' && num % 2 !== 0) ||
              (title === 'even' && num % 2 === 0)) {
              list.push(num)
            }
          })

          tableList.push({
            title: tab.titleList[index],
            list: list.sort((a, b) => a - b)
          })
        })
        tableObj[tabKey] = tableList

        if (tabKey === 'fowl') {
          tableObj[tabKey] = fowlData
        }
      })

      return tableObj
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .p-data {
    @extend %g-body;
    .g-tab {
      margin-top: .2rem;
      padding: 0 .15rem;
      .m-tab {
        @include border-1px($bd-main, bottom);
        width: 100%;
        text-align: center;
        background-color: $white;
        border-radius: .1rem .1rem 0 0;
        overflow: hidden;
        .tab-item {
          width: 25%;
          height: .7rem;
          font-size: .26rem;
          line-height: .7rem;
        }
      }
    }

    .g-content {
      @extend %g-scroll;
      padding: 0 .15rem;
      .m-table {
        background-color: $white;
        .line {
          @extend %u-flex-box;
          @include border-1px($bd-main, bottom);
          .title {
            height: 100%;
            width: 1.2rem;
            text-align: center;
            font-size: .3rem;
            color: $text-sub;
          }
          .ball-box {
            @include border-1px($bd-main, left);
            @extend %u-flex-item;
            padding: .1rem;
            .item {
              font-size: .3rem;
              padding: .1rem;
              color: $text-assist;
            }
          }
        }
      }
    }
  }
</style>
