<template>
  <div class="p-trend">
    <KsHeader :title="`${titleIssue}开奖走势`" rightText="资料" @tapRight="$router.push({path: '/trend/data'})"/>

    <div class="g-tab">
      <Tab v-model="tabIndex">
        <TabItem v-for="tab in tabList" :key="tab.key">{{tab.name}}</TabItem>
      </Tab>
    </div>
    <div class="g-nav" v-if="!isResult && !isStati">
      <div class="line c-bg-light c-text-all">
        <span class="period">期号</span>
        <span class="count" v-for="(item, index) in tabList[tabIndex].titleList" :key="index">{{item}}</span>
      </div>
    </div>

    <section class="g-content" v-if="resultList" ref="scroll">
      <div :class="`g-table ${isResult || isStati ? 'result' : 'has-title'}`">
        <div class="table">
          <template v-if="isResult">
            <div class="line" v-for="result in resultList" :key="result.period">
              <p class="period">
                <span class="c-text">{{result.period}}</span>期
                <br>
                <span class="fs-18">{{result.date}}</span>
              </p>
              <div class="ball-box" v-for="(num, index) in result.prizeNumber.split(',').slice(0, -1)" :key="index">
                <b :class="`ball ball-${numberMap[num].color}`">{{num}}</b>
                <p>{{numberMap[num].zodiac}}<span class="split">/</span>{{numberMap[num].wuXing}}</p>
              </div>
              <div class="ball-box">
                <span class="icon">+</span>
              </div>
              <div class="ball-box">
                <b :class="`ball ball-${numberMap[result.prizeNumber.substr(-2)].color}`">{{result.prizeNumber.substr(-2)}}</b>
                <p>{{numberMap[result.prizeNumber.substr(-2)].zodiac}}<span
                  class="split">/</span>{{numberMap[result.prizeNumber.substr(-2)].wuXing}}</p>
              </div>
            </div>
          </template>

          <template v-else-if="isStati && statiData">
            <div class="record-list" v-for="item in tabList[tabIndex].statiList" :key="item.key">
              <p class="u-module-title c-text"><i class="str c-bg"></i>{{item.name}}</p>
              <div class="box" v-for="zodiac in statiData[item.key]" :key="zodiac.name">
                <div class="zodiac"><span class="name">{{zodiac.name}}</span></div>
                <div class="detail">
                  <div class="c-text c-bg-light item">未开期数</div>
                  <div class="c-text c-bg-light item">最近开出期数</div>
                  <div class="content item period">{{zodiac.noOpenCount}}期</div>
                  <div class="content item">
                    <p>{{zodiac.recentOpenPeriod}}期</p>
                    <div v-if="item.key === 'zodiac'">
                      <b :class="`ball small-ball ball-${numberMap[num].color}`" v-for="num in zodiac.content"
                         :key="num">{{num}}</b>
                    </div>
                    <div class="text" v-else>
                      <span v-for="num in zodiac.content" :key="num">{{num}}</span>
                    </div>
                  </div>
                  <div class="c-text c-bg-light item">最高未开期数</div>
                  <div class="c-text c-bg-light item">最高连开纪录</div>
                  <div class="content item">
                    <p>{{zodiac.maxNoOpenCount}}期</p>
                    <div class="issue">{{zodiac.maxNoOpenStart}}-{{zodiac.maxNoOpenEnd}}期</div>
                  </div>
                  <div class="content item">
                    <p>{{zodiac.maxOpenCount}}期</p>
                    <div class="issue">{{zodiac.maxOpenStart}}-{{zodiac.maxOpenEnd}}期</div>
                  </div>
                </div>
              </div>
            </div>
          </template>

          <template v-else>
            <div class="line" v-for="item in tableObj[tabKey]" :key="item.period">
              <span class="period">{{item.period}}期</span>
              <span :class="`count ${item.color || ''}`" v-for="(item, i) in item.list" :key="i">{{item.num}}</span>
            </div>
          </template>
        </div>

        <SiteFooter/>
      </div>
      <UpArrow/>
    </section>
  </div>
</template>

<script>
import { Tab, TabItem } from 'COMPONENTS/Tab'
import { mapGetters } from 'vuex'
import UpArrow from 'COMPONENTS/UpArrow'

export default {
  name: '',

  title: '走势',

  components: {
    Tab,
    TabItem,
    UpArrow
  },

  data () {
    return {
      tabIndex: 0,
      tabList: [{
        name: '开奖',
        key: 'result',
        titleList: []
      }, {
        name: '尾号',
        key: 'last',
        titleList: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
      }, {
        name: '头号',
        key: 'first',
        titleList: [0, 1, 2, 3, 4]
      }, {
        name: '色波',
        key: 'color',
        titleList: ['红波', '蓝波', '绿波'],
        titleValue: ['red', 'blue', 'green']
      }, {
        name: '五行',
        key: 'wuXing',
        titleList: ['金', '木', '水', '火', '土']
      }, {
        name: '生肖',
        key: 'zodiac',
        titleList: ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪']
      }, {
        name: '统计',
        key: 'stati',
        titleList: [],
        statiList: [{
          name: '特肖记录',
          key: 'zodiac'
        }, {
          name: '前后生肖',
          key: 'qianHouLiuXiao'
        }, {
          name: '野家生肖',
          key: 'yeJiaShengXiao'
        }]
      }],
      statiData: null,
      resultList: null,
      tableObj: null
    }
  },

  computed: {
    ...mapGetters({
      numberMap: 'numberMap'
    }),

    titleIssue () {
      if (!this.resultList) {
        return ''
      }

      const item = this.resultList[0]
      return `${new Date(item.date).getFullYear()}年${item.period}期`
    },

    tabKey () {
      return this.tabList[this.tabIndex].key
    },

    isResult () {
      return this.tabKey === 'result'
    },

    isStati () {
      return this.tabKey === 'stati'
    }
  },

  created () {
    this.fetchPrizeNumber()
  },

  watch: {
    tabIndex (index) {
      this.$refs.scroll.scrollTop = 0
      if (index === 6 && !this.statiData) {
        this.fetchStatiData()
      }
    }
  },

  methods: {
    fetchStatiData () {
      this.$loading.show()
      this.$server.fetch('statiData').then(res => {
        this.$loading.hide()
        this.statiData = res
      })
    },

    fetchPrizeNumber () {
      this.$loading.show()
      this.$server.fetch('prizeNumber').then(result => {
        this.$loading.hide()
        this.resultList = result
        this.tableObj = this.getTableObj()
      })
    },

    getTableObj () {
      const tableObj = {}

      this.tabList.forEach(tab => {
        const tabKey = tab.key
        const tableList = []
        const countArr = []
        const curTitleValue = tab.titleValue || tab.titleList

        const resultArr = this.resultList.slice().reverse()
        resultArr.forEach((result, index) => {
          const list = []
          const num = result.prizeNumber.slice(-2)

          curTitleValue.forEach((item, i) => {
            // 配置遗漏数
            if (index === 0) {
              countArr[i] = 1
            } else {
              if (tableList[index - 1].list[i].color) {
                countArr[i] = 1
              } else {
                countArr[i]++
              }
            }

            if ((this.numberMap[num][tabKey] === item) ||
              (tabKey === 'last' && num % 10 === item) ||
              (tabKey === 'first' && Math.floor(num / 10) === item)) {
              list.push({
                num,
                color: this.numberMap[num].color
              })
            } else {
              list.push({
                num: countArr[i]
              })
            }
          })

          !!list.length && tableList.push({
            period: result.period,
            list
          })
        })
        tableObj[tabKey] = tableList.reverse()
      })
      return tableObj
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-trend {
    @extend %g-body;
    padding-bottom: .98rem;
    .g-tab {
      margin-top: .2rem;
      padding: 0 .15rem;
      .m-tab {
        @include border-1px($bd-main, bottom);
        width: 100%;
        text-align: center;
        background-color: $white;
        border-radius: .1rem .1rem 0 0;
        overflow: hidden;
        .tab-item {
          width: 14.28%;
          height: .7rem;
          font-size: .26rem;
          line-height: .7rem;
        }
      }
    }

    .g-nav {
      padding: 0 .15rem;
      line-height: .6rem;
      .period {
        @include border-1px($bd-main, bottom);
      }
      .count {
        @include border-1px($bd-main, left bottom);
      }
    }

    .line {
      @extend %u-flex-box;
      text-align: center;
      .period {
        width: 1.2rem;
        color: $text-assist;
      }
      .count {
        @extend %u-flex-item;
        color: $text-sub;
        &.red {
          color: $white;
          background-color: $ball-bg-red;
        }
        &.blue {
          color: $white;
          background-color: $ball-bg-blue;
        }
        &.green {
          color: $white;
          background-color: $ball-bg-green
        }
      }
    }

    .g-content {
      @extend %g-scroll;
      position: relative;
      padding: 0 .15rem;
      height: 100%;

      .g-table {
        height: 100%;
        &.result {
          /* 开奖 */
          .line {
            .period {
              height: 1.08rem;
              padding-top: .24rem;
              @include border-1px($bg-main, right bottom);
            }
            .ball-box {
              height: 1.08rem;
              @extend %u-flex-item;
              color: $text-main;
              text-align: center;
              .icon {
                font-size: .48rem;
              }
              .split {
                color: $text-light;
              }
            }
          }
        }
        &.has-title {
          .line {
            // height: .6rem;
            line-height: .6rem;
            .period {
              @include border-1px($bg-main, bottom);
            }
            .count {
              @include border-1px($bg-main, left bottom);
            }
          }
        }

        .table {
          min-height: 100%;
          background-color: $white;
          .record-list {
            .box {
              position: relative;
              .zodiac {
                @include border-1px($bd-main, bottom);
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                width: 1.2rem;
                .name {
                  @include set-center();
                  color: $text-sub;
                }
              }
              .detail {
                @extend %u-flex-box;
                flex-wrap: wrap;
                justify-content: flex-start;
                margin-left: 1.2rem;
                .item {
                  @include border-1px($bd-main, left bottom);
                  width: 50%;
                  text-align: center;
                  padding: .2rem .1rem;
                  &.content {
                    padding: .1rem;
                    height: 1rem;
                    color: $text-sub;
                    &.period {
                      line-height: .8rem;
                    }
                    .issue {
                      font-size: .2rem;
                      margin-top: .1rem;
                      color: $text-assist;
                    }
                    .text {
                      color: $text-assist;
                      margin-top: .1rem;
                      letter-spacing: .12rem;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
</style>
