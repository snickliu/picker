<template>
  <div class="p-post-list">
    <KsHeader :title="title" leftIcon="arrow-left"/>
    <section class="g-content">
      <PostList :pageSize="pageSize" :list="postList"/>
    </section>
    <PageView v-model="page" :totalPage="totalPage"/>
    <SiteFooter :fixButton="true"/>
  </div>
</template>

<script>
import PostList from 'UI/Modules/PartUtils/PostList'
import PageView from 'UI/Modules/PartUtils/PageView'

export default {
  name: '',

  components: {
    PostList,
    PageView
  },

  data () {
    return {
      page: 1,
      pageSize: 10,
      postList: {},
      totalPage: 1
    }
  },

  computed: {
    title () {
      const query = this.$route.query
      return query.search ? '搜索结果' : query.userId ? '历史记录' : '帖子列表'
    }
  },

  created () {
    this.fetchPostList()
  },

  watch: {
    page: 'fetchPostList'
  },

  methods: {
    fetchPostList () {
      const query = this.$route.query

      const param = query.search ? {
        keyword: query.search
      } : query.userId ? {
        timeType: 1,
        userId: query.userId
      } : {}

      this.$loading.show()
      this.$server.fetch('postList', {
        page: this.page,
        size: this.pageSize,
        ...param
      }).then(res => {
        this.$loading.hide()
        this.postList = res.list
        this.totalPage = res.totalPage
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-post-list {
    @extend %g-body;
    .g-content {
      @extend %g-scroll;
      background-color: $white;
      margin: .3rem .2rem 0 .2rem;
    }

    .m-page-view {
      margin: 0 .2rem;
    }
  }
</style>
