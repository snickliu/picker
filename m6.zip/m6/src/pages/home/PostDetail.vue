<template>
  <div class="p-post-detail">
    <KsHeader title="看帖" leftIcon="arrow-left" rightText="历史记录" @tapRight="$router.push({path: '/home/postList', query: {userId: postDetail.userId}})"/>
    <section class="g-content">
      <div v-if="advertising[0]&&advertising[0].pic" @click="go(advertising[0].link)">
        <BaseImage class="banner-img"
        :defaultSrc="require('IMAGES/default/pic.png')"
        :imgSrc="advertising[0].pic"/>
      </div>
      <div class="banner-two-list u-module-chunk" v-if="advertising[1]&&advertising[1].datas">
        <ul class="list">
          <li class="item" v-for="(item,i) in advertising[1].datas" :key="i" @click="go(item.link)">
            <img class="u-icon-shake" src="~IMAGES/icons/arrow.png" alt="">
            {{item.text}}
          </li>
        </ul>
      </div>
      <div class="post-content u-module-chunk" v-if="postDetail">
        <div class="post-title">
          <p class="title" v-html="title"></p>
          <div class="remark">
            <span class="u-comment"><i class="iconfont icon-eye"></i>{{postDetail.viewCount}}</span>
            <span class="u-comment"><i class="iconfont icon-comment"></i>{{postDetail.commentCount}}</span>
          </div>
        </div>
        <div class="post-detail">
          <div class="u-post-auth">
            <BaseImage :defaultSrc="require('IMAGES/avatar.png')" :imgSrc="postDetail.avatar"/>
            <div class="auth">
              <span class="name">{{postDetail.nickname}}</span>
              <span class="lz c-bd c-text">楼主</span>
              <p class="date">{{postDetail.createTime}}</p>
            </div>
            <div class="remark">
              <span class="u-comment" @click="markComment('up', postDetail)">
            <i class="iconfont icon-thumbup" :class="{'c-text': postDetail.isUp}"></i>
            {{postDetail.upCount}}
          </span>
              <span class="u-comment" @click="markComment('down', postDetail)">
            <i class="iconfont icon-thumbdown" :class="{'c-text': postDetail.isDown}"></i>
            {{postDetail.downCount}}
          </span>
            </div>
          </div>
          <pre class="content" v-html="postDetail.content">
          </pre>
        </div>
        <p class="tip">该内容于:（{{postDetail.modifyTime}}) 被【{{postDetail.lastModifyUser}}】重新编辑</p>
        <p class="notice" v-if="advertising[2]&&advertising[2].sign" v-html="advertising[2].sign"></p>
      </div>
      <div v-if="advertising[3]&&advertising[3].pic" @click="go(advertising[3].link)">
        <BaseImage class="banner-img"
        :defaultSrc="require('IMAGES/default/pic.png')"
        :imgSrc="advertising[3].pic"/>
      </div>
      <LotteryResult01/>
      <Comment v-if="postSwitch"/>
      <UpArrow/>
    </section>
    <QuickComment v-if="commentSwitch"/>
    <GeneralPopup
      if="imgData"
      :type="imgData.type"
      :title="imgData.title"
      :conent="imgData.content"
      :imgUrl="imgData.type==='image'?imgData.link:''"
      :buttonText="'查看详情'"
      @btnHandling="go('')"
      v-model="dialogShow">
    </GeneralPopup>
  </div>
</template>

<script>
import { LotteryResult01 } from 'UI/Modules/LotteryResult'
import Comment from 'UI/Modules/GlobalComment/Comment'
import QuickComment from 'UI/Modules/GlobalComment/QuickComment'
import UpArrow from 'COMPONENTS/UpArrow'
import { mapGetters } from 'vuex'
import GeneralPopup from 'COMPONENTS/GeneralPopup'

export default {
  name: '',

  components: {
    QuickComment,
    LotteryResult01,
    Comment,
    UpArrow,
    GeneralPopup
  },

  data () {
    return {
      postDetail: null,
      advertising: [],
      dialogShow: false
    }
  },

  computed: {
    ...mapGetters({
      siteConfig: 'siteConfig'
    }),
    postSwitch () {
      return this.siteConfig.config && this.siteConfig.config.addTopicSwitch === '1'
    },
    commentSwitch () {
      return this.siteConfig.config && this.siteConfig.config.quickCommentSwitch === '1'
    },
    title () {
      return this.postDetail.title.replace(/\[/g, '<').replace(/\]/g, '>')
    },
    imgData () {
      const dialog = this.siteConfig.dialogConfig
      if (!dialog) {
        return null
      }
      let data = {}
      dialog.map((item, index) => {
        if (item.categoryAlias === 'topicDialog') {
          data = item
        }
      })
      return data
    }
  },

  created () {
    setTimeout(() => {
      this.dialogShow = true
    }, 1000)
    this.fetchAdvertising()
    this.fetchPostDetail()
  },

  activated () {
  },

  methods: {
    go (url) {
      location.href = url || this.imgData.link
    },
    fetchAdvertising () {
      this.$server.fetch('advertising').then(res => {
        this.advertising = res
      })
    },
    markComment (action) {
      const isMark = `is${action.slice(0, 1).toUpperCase()}${action.slice(1)}`
      if (this.postDetail[isMark]) {
        return
      }

      const count = this.postDetail[`${action}Count`]
      this.$server.fetch(`${action}Post`, {
        postId: this.$route.query.postId
      }).then(() => {
        this.postDetail[isMark] = 1
        this.postDetail[`${action}Count`] = (count + 1)
      })
    },

    fetchPostDetail () {
      this.$server.fetch('postDetail', {
        postId: this.$route.query.postId
      }).then(res => {
        this.postDetail = res
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-post-detail {
    @extend %g-body;
    .g-content {
      @extend %g-scroll;
      .banner-img {
        margin: .2rem 0;
        height: auto;
      }

      .banner-two-list {
        .list {
          .item {
            display: inline-block;
            width: 50%;
            padding: .18rem .2rem;
            text-align: center;
            @include border-1px($bd-main, bottom);
            &:nth-child(odd) {
              @include border-1px($bd-main, right bottom);
            }
            &:last-child:after, &:nth-last-child(2):after {
              border-bottom-color: $white;
            }
          }
        }
      }

      .post-content {
        .post-title {
          @include border-1px($bd-main, bottom);
          @extend %u-flex-box;
          padding: .2rem;
          .title {
            @extend %u-flex-item;
            font-size: .28rem;
          }
        }
        .post-detail {
          @include border-1px($bd-main, bottom);
          padding: .2rem;
          .content {
            padding-top: .2rem;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
        .tip {
          @include border-1px($bd-main, bottom);
          padding: .2rem;
          color: $text-light;
        }
        .notice {
          padding: .2rem;
          color: $text-sub;
        }
      }
    }
  }
</style>
