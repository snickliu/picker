<template>
  <div class="p-home" v-if="modulesList">
    <section class="g-content">
      <component
        v-if="modulesList"
        v-for="(module, index) in modulesList"
        :key="index"
        :is="module.component"
        :data="module.data"></component>

      <SiteFooter/>
      <UpArrow/>
    </section>
    <GeneralPopup
      if="imgData"
      :type="imgData.type"
      :title="imgData.title"
      :conent="imgData.content"
      :imgUrl="imgData.type==='image'?imgData.link:''"
      :buttonText="'查看详情'"
      @btnHandling="go"
      v-model="dialogShow">
    </GeneralPopup>
    <QuickComment v-if="commentSwitch"/>
  </div>
</template>

<script>
import { modulesMap } from 'UI/Modules/index.js'
import { mapGetters } from 'vuex'
import QuickComment from 'UI/Modules/GlobalComment/QuickComment'
import UpArrow from 'COMPONENTS/UpArrow'
import GeneralPopup from 'COMPONENTS/GeneralPopup'

export default {
  name: '',

  title: '首页',

  components: {
    QuickComment,
    UpArrow,
    GeneralPopup,
    ...modulesMap.components
  },

  data () {
    return {
      dialog: null,
      dialogShow: false
    }
  },
  computed: {
    ...mapGetters([
      'siteConfig'
    ]),
    commentSwitch () {
      return this.siteConfig.config && this.siteConfig.config.quickCommentSwitch === '1'
    },
    imgData () {
      const dialog = this.siteConfig.dialogConfig
      if (!dialog) {
        return null
      }
      let data = {}
      dialog.map((item, index) => {
        if (item.categoryAlias === 'homeDialog') {
          data = item
        }
      })
      return data
    },
    modulesList () {
      const modules = this.$store.getters.siteConfig.modules

      if (!modules) {
        return null
      }
      return modules.map(item => {
        return {
          component: modulesMap.map[item.styleAlias],
          data: item.datas
        }
      })
    }
  },

  created () {
    setTimeout(() => {
      this.dialogShow = true
    }, 1000)
  },

  methods: {
    go () {
      location.href = this.imgData.link
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-home {
    padding-bottom: .98rem;
    @extend %g-body;
    .g-content {
      @extend %g-scroll;
      overflow-x: hidden;
    }
    .m-up-arrow {
      bottom: 2rem;
    }
  }
</style>
