<template>
  <div class="p-main">
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive"/>
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive"/>

    <component v-if="homeNav" :is="homeNav.component" :data="homeNav.data"></component>
  </div>
</template>
<script>
import { homeNavMap } from 'UI/Modules/index.js'

export default {
  name: '',

  components: {
    ...homeNavMap.components
  },

  data () {
    return {}
  },

  computed: {
    homeNav () {
      const homeNav = this.$store.getters.siteConfig.homeNav
      if (!homeNav) {
        return null
      }
      const modules = this.$store.getters.siteConfig.modules
      let navData = modules[modules.length - 1].moduleAlias === 'tabNavigatBar' ? modules[modules.length - 1].datas : ''
      return {
        component: homeNavMap.map[homeNav.component],
        data: navData || homeNav.data
      }
    }
  },

  created () {
  },

  methods: {}
}
</script>
<style lang="scss" scoped>
</style>
