<template>
  <div class="p-edit-post">
    <KsHeader title="快速发帖" leftIcon="arrow-left"/>
    <section class="g-content">
      <div class="tool-list c-text-all">
        <span class="tool" @click="fetch(1)">加载上期帖子</span>
        <span class="tool" @click="fetch(2)">加载上期标题</span>
        <span class="tool" @click="fetch(3)">加载上期内容</span>
      </div>
      <div class="title_post">
        <input v-model="titlePost" type="text" placeholder="请输入标题（限120字内）" maxlength="120"/>
      </div>
      <div class="edit-box" id="editor">
      </div>
      <KsButton :disable="disable" @onTap="submit">发布</KsButton>
    </section>
    <SiteFooter :fixBottom="true"/>
  </div>
</template>

<script>
import KsButton from 'UI/Button'
import WangEditor from 'wangeditor'
import emojiList from 'UTILS/data/emojiList'
import { mapGetters } from 'vuex'

export default {
  name: '',

  title: '快速发帖',

  components: {
    KsButton
  },
  computed: {
    ...mapGetters({
      siteConfig: 'siteConfig'
    }),
    postSwitch () {
      return this.siteConfig.config && this.siteConfig.config.addTopicSwitch === '1'
    }
  },
  data () {
    return {
      disable: false,
      editContent: '',
      editor: null,
      titlePost: ''
    }
  },

  created () {
    if (!this.postSwitch) {
      this.$router.replace({
        name: 'userCenter'
      })
    }
    this.$nextTick(() => {
      this.editor = new WangEditor('#editor')
      this.editor.customConfig.menus = [
        'emoticon',
        'fontSize',
        'fontName',
        'foreColor',
        'backColor',
        'justify',
        'bold',
        'italic',
        'underline',
        'link',
        'image'
      ]
      // 表情面板可以有多个 tab ，因此要配置成一个数组。数组每个元素代表一个 tab 的配置
      this.editor.customConfig.emotions = [{
        // tab 的标题
        title: '表情',
        // type -> 'emoji' / 'image'
        type: 'emoji',
        // content -> 数组
        content: emojiList
      }]

      // 显示“上传图片”的tab
      this.editor.customConfig.uploadImgShowBase64 = true
      // 隐藏“网络图片”tab
      this.editor.customConfig.showLinkImg = false
      // 将图片大小限制为 1M
      this.editor.customConfig.uploadImgMaxSize = 1024 * 1024
      this.editor.create()
    })
  },
  methods: {
    // Forum Post
    // title 必须 string 标题
    // content 必须 string 内容
    submit () {
      // debugger // eslint-disable-line
      this.editContent = this.editor.txt.text()
      if (!this.editContent || !this.titlePost) {
        this.$toast('请输入帖子信息')
        return
      }
      this.$loading.show()
      let param = {
        title: this.titlePost,
        content: this.editor.txt.html()
      }
      this.$server.fetch('forumPost', param).then(res => {
        this.$loading.hide()
        this.$toast('发帖成功')
        // 清空输入框内容
        this.editor.txt.clear()
        this.$router.goBack()
      }).catch(err => {
        this.$loading.hide()
        this.$toast(err.message)
      })
    },
    // 查询帖子
    fetch (type) {
      this.$loading.show()
      this.$server.fetch('getLastPost').then(res => {
        this.$loading.hide()
        this.btn(type, res)
      }).catch(err => {
        this.$loading.hide()
        this.$toast(err.message)
      })
    },
    // 头部按钮事件
    btn (type, data) {
      switch (type) {
        case 1:
          this.titlePost = data.title
          this.editor.txt.text(data.content)
          // 赋值利用从后添加内容移动光标到最后
          this.editor.txt.append()
          break
        case 2:
          this.titlePost = data.title
          break
        case 3:
          this.editor.txt.text(data.content)
          // 赋值利用从后添加内容移动光标到最后
          this.editor.txt.append()
          break
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-edit-post {
    @extend %g-body;
    .g-content {
      @extend %g-scroll;
      .tool-list {
        @extend %u-flex-box;
        justify-content: space-between;
        text-align: center;
        padding: .3rem .2rem;
        font-size: .28rem;
        .tool {
          width: 2.1rem;
          line-height: .6rem;
          background-color: $white;
          border-radius: .1rem;
        }
      }
      .title_post {
        background-color: $white;
        margin: 0 0.2rem 0 0.2rem;
        input {
          margin: 0.2rem;
          font-size: 0.3rem;
          height: 0.42rem;
        }
        ::-webkit-input-placeholder { /* WebKit browsers */
          color: $text-light;
        }
        :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
        color: $text-light;
        }
        ::-moz-placeholder { /* Mozilla Firefox 19+ */
          color: $text-light;
        }
        :-ms-input-placeholder { /* Internet Explorer 10+ */
          color: $text-light;
        }
      }
      .edit-box {
        background-color: $white;
        margin: .1rem .2rem .8rem .2rem;
      }
    }
  }
</style>
