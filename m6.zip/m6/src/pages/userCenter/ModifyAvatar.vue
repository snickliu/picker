<template>
  <div class="p-modify-avatar">
    <KsHeader title="修改头像" leftIcon="arrow-left"/>
    <section class="g-content">
      <div class="avatar">
        <BaseImage :defaultSrc="require('IMAGES/avatar.png')" :imgSrc="avatarSrc"/>
        <p class="input c-bd" @click="chooseAvatar">选择本地头像</p>
        <input type="file" accept="image/*" style="display: none" ref="fileInput" @change="changeAvatar">
      </div>
      <div class="list">
        <ul class="img-list" v-if="avatarList">
          <li class="img" :class="{'c-bd active': avatarSrc === item}" v-for="item in avatarList" :key="item"
              @click="selectAvatar(item)">
            <BaseImage :defaultSrc="require('IMAGES/avatar.png')" :imgSrc="item"/>
            <i class="iconfont icon-select c-text"></i>
          </li>
        </ul>
      </div>
      <KsButton :disable="disable" @onTap="modify">保存</KsButton>
    </section>
    <SiteFooter :fixBottom="true"/>
  </div>
</template>

<script>
import KsButton from 'UI/Button'
import { mapGetters } from 'vuex'

export default {
  name: '',

  title: '修改头像',

  meta: {
    needLogin: true
  },

  components: {
    KsButton
  },

  data () {
    return {
      avatarList: null,
      avatarSrc: null,
      disable: true,
      avatarInfo: {}
    }
  },

  computed: {
    ...mapGetters({
      userInfo: 'userInfo'
    })
  },

  created () {
    this.avatarSrc = this.userInfo.avatar
    this.fetchDefaultAvatar()
  },

  methods: {
    modify () {
      this.$loading.show()
      this.$server.fetch('modifyAvatar', this.avatarInfo).then(res => {
        this.$loading.hide()
        this.$store.commit(this.$mutationType.UPDATE_USERINFO, res)
        this.$toast('头像修改成功')
        this.$router.goBack()
      }).catch(err => {
        this.$loading.hide()
        this.$toast(err.message)
      })
    },

    fetchDefaultAvatar () {
      this.$loading.show()
      this.$server.fetch('defaultAvatar').then(res => {
        this.$loading.hide()
        this.avatarList = res
      })
    },

    selectAvatar (item) {
      if (this.avatarSrc !== item) {
        this.disable = false
        this.avatarSrc = item
        this.avatarInfo = {
          avatar: item
        }
        return
      }

      this.disable = true
      this.avatarSrc = this.userInfo.avatar
    },

    chooseAvatar () {
      this.$refs.fileInput.click()
    },

    changeAvatar (ev) {
      const files = ev.target.files
      if (files && files.length > 0) {
        const file = files[0]

        if (file.size > 1024 * 1024) {
          this.$alert('图片大小不能超过1M！')
          return
        }

        const vm = this
        const reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = function (ev) {
          vm.avatarSrc = this.result
          vm.avatarInfo = {
            file: this.result
          }
        }

        this.disable = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-modify-avatar {
    background-color: $white;
    .g-content {
      .avatar {
        text-align: center;
        padding: .24rem;
        .m-base-img {
          width: 1.6rem;
          height: 1.6rem;
          margin: auto;
          border-radius: .2rem;
          overflow: hidden;
        }
        .input {
          width: 4rem;
          padding: .1rem;
          text-align: center;
          margin: .16rem auto .1rem auto;
          font-size: .3rem;
          color: $text-sub;
          border: 1px solid;
          border-radius: .1rem;
        }
      }
      .list {
        height: 5.6rem;
        overflow: scroll;
        .img-list {
          @extend %u-flex-box;
          flex-wrap: wrap;
          justify-content: space-between;
          margin-bottom: .1rem;
          padding: 0 .3rem;
          .img {
            position: relative;
            display: inline-block;
            margin-bottom: .2rem;
            width: 1.2rem;
            height: 1.2rem;
            &.active {
              border: .04rem solid;
              .iconfont {
                display: inline;
              }
            }
            > img {
              width: 100%;
              height: 100%;
            }
            .iconfont {
              position: absolute;
              right: -1px;
              bottom: -1px;
              display: none;
            }
          }
        }
      }
    }
  }
</style>
