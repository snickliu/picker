<template>
  <div class="p-modify-pwd">
    <KsHeader title="修改密码" leftIcon="arrow-left"/>
    <section class="g-content">
      <div class="u-forms">
        <FormInput v-model="pwdInfo.oldPassword" type="password" placeholder="请输入旧密码">
          <span class="title">旧密码</span>
        </FormInput>
        <FormInput v-model="pwdInfo.newPassword" type="password" placeholder="请输入新密码">
          <span class="title">新密码</span>
        </FormInput>
        <FormInput v-model="repeatPwd" type="password" placeholder="请再次输入新密码">
          <span class="title">确认新密码</span>
        </FormInput>
        <div class="form">
          <FormInput v-model="pwdInfo.checkCode" placeholder="请输入验证码">
            <span class="title">验证码</span>
          </FormInput>
          <BaseImage class="code" :full="true" :imgSrc="verifyCode" @click.native="refreshCode('pwd')"/>
        </div>
        <div class="form-tip">
          <span class="need c-text">*</span>密码规则：三个字符或以上
        </div>
      </div>

      <KsButton :disable="disable" @onTap="modify">确定</KsButton>
    </section>
    <SiteFooter :fixBottom="true"/>
  </div>
</template>

<script>
import FormInput from 'UI/FormInput'
import KsButton from 'UI/Button'

const VERIFY_CODE = '/api/General/captcha'

export default {
  name: '',

  title: '修改密码',

  meta: {
    needLogin: true
  },

  components: {
    FormInput,
    KsButton
  },

  data () {
    return {
      repeatPwd: '',
      pwdInfo: {
        oldPassword: '',
        newPassword: '',
        checkCode: ''
      },
      verifyCode: VERIFY_CODE,
      lengthMap: {
        oldPassword: 3,
        newPassword: 3,
        checkCode: 4
      }
    }
  },

  computed: {
    disable () {
      return Object.keys(this.pwdInfo).some(item => this.pwdInfo[item].length < this.lengthMap[item]) || this.repeatPwd.length < 3
    }
  },

  created () {
  },

  methods: {
    refreshCode (eventName) {
      this.verifyCode = VERIFY_CODE + '?_ts=' + new Date().getTime()
      this[`${eventName}Info`].checkCode = ''
    },

    modify () {
      if (this.repeatPwd !== this.pwdInfo.newPassword) {
        this.$toast('两次输入的新密码不同')
        return
      }

      this.$loading.show()
      this.$server.fetch('modifyPwd', this.pwdInfo).then(res => {
        this.$loading.hide()
        this.$store.commit(this.$mutationType.UPDATE_USERINFO, res)
        this.$toast('密码修改成功')
        this.$router.goBack()
      }).catch(err => {
        this.$loading.hide()
        this.$toast(err.message)
        this.refreshCode('pwd')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-modify-pwd {
    background-color: $white;
    .g-content {
      .u-forms {
        margin-bottom: 1.4rem;
        .title {
          width: 1.8rem;
        }
      }
    }
  }
</style>
