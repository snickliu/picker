<template>
  <div class="p-user-center">
    <header class="g-header">
      <img src="~IMAGES/bg-user.png" alt="">
      <!--已登录-->
      <div class="avatar" v-if="isLogin">
        <BaseImage :defaultSrc="require('IMAGES/avatar.png')" :imgSrc="userInfo.avatar" />
        <p class="name">{{userInfo.userName}}</p>
      </div>
      <!--未登录-->
      <div class="btns" v-else>
        <span class="btn" :class="{active: type === 'login'}" @click="type = 'login'">登录</span>
        <span class="btn" :class="{active: type === 'reg'}" @click="type = 'reg'">注册</span>
      </div>
    </header>
    <section class="g-content">
      <!--未登录-->
      <div class="box-content" v-if="!isLogin">
        <!--登录-->
        <template v-if="type === 'login'">
          <div class="u-forms">
            <FormInput v-model="loginInfo.username" placeholder="请输入用户名">
              <i class="iconfont icon-modifyavatar"
                 :class="{'c-text': loginInfo.username.length >= lengthMap.username}"></i>
            </FormInput>
            <FormInput v-model="loginInfo.password" type="password" placeholder="请输入密码">
              <i class="iconfont icon-password"
                 :class="{'c-text': loginInfo.password.length >= lengthMap.password}"></i>
            </FormInput>
            <div class="form">
              <FormInput v-model="loginInfo.checkCode" placeholder="请输入验证码">
                <i class="iconfont icon-verificationcode"
                   :class="{'c-text': loginInfo.checkCode.length >= lengthMap.checkCode}"></i>
              </FormInput>
              <BaseImage class="code" :full="true" :imgSrc="verifyCode" @click.native="refreshCode('login')"/>
            </div>
          </div>
          <KsButton :disable="loginDisable" @onTap="tapEvent('login')">登录</KsButton>
        </template>
        <!--注册-->
        <template v-else-if="type === 'reg'">
          <div class="u-forms">
            <FormInput v-model="regInfo.username" placeholder="不少于2个汉字的用户名">
              <span class="need c-text">*</span>
              <span class="title">用户名</span>
            </FormInput>
            <FormInput v-model="regInfo.password" type="password" placeholder="密码不能少于3位">
              <span class="need c-text">*</span>
              <span class="title">密码</span>
            </FormInput>
            <FormInput v-model="regInfo.mobile" placeholder="请输入手机号">
              <span class="title">手机号</span>
            </FormInput>
            <FormInput v-model="regInfo.email" placeholder="请输入邮箱">
              <span class="title">邮箱</span>
            </FormInput>
            <div class="form">
              <FormInput v-model="regInfo.checkCode" placeholder="请输入验证码">
                <span class="need c-text">*</span>
                <span class="title">验证码</span>
              </FormInput>
              <BaseImage class="code" :full="true" :imgSrc="verifyCode" @click.native="refreshCode('reg')"/>
            </div>
          </div>
          <KsButton :disable="regDisable" @onTap="tapEvent('reg')">注册</KsButton>
        </template>
      </div>
      <!--已登录-->
      <div class="user-list" v-else>
        <div class="box c-bd c-text-all" @click="goPost">
          <i class="iconfont icon-post"></i>
          <p class="text">发表新帖</p>
          <i class="iconfont icon-arrow-right"></i>
        </div>
        <router-link tag="div" :to="{path: '/userCenter/modifyAvatar'}" class="box c-bd c-text-all">
          <i class="iconfont icon-modifyavatar"></i>
          <p class="text">修改头像</p>
          <i class="iconfont icon-arrow-right"></i>
        </router-link>
        <router-link tag="div" :to="{path: '/userCenter/modifyPwd'}" class="box c-bd c-text-all">
          <i class="iconfont icon-password"></i>
          <p class="text">修改密码</p>
          <i class="iconfont icon-arrow-right"></i>
        </router-link>
        <div class="box c-bd c-text-all" @click="logout">
          <i class="iconfont icon-dropout"></i>
          <p class="text">退出</p>
          <i class="iconfont icon-arrow-right"></i>
        </div>
      </div>
    </section>
    <SiteFooter :fixBottom="true"/>
  </div>
</template>

<script>
import FormInput from 'UI/FormInput'
import KsButton from 'UI/Button'
import { mapGetters } from 'vuex'

const VERIFY_CODE = '/api/General/captcha'

export default {
  name: '',

  title: '用户中心',

  components: {
    FormInput,
    KsButton
  },

  data () {
    return {
      type: this.$route.query.type || 'login',
      loginInfo: {
        username: '',
        password: '',
        checkCode: ''
      },
      regInfo: {
        username: '',
        password: '',
        mobile: '',
        email: '',
        checkCode: ''
      },
      verifyCode: VERIFY_CODE,
      lengthMap: {
        username: 2,
        password: 3,
        checkCode: 4,
        mobile: 0,
        email: 0
      }
    }
  },

  computed: {
    ...mapGetters({
      isLogin: 'isLogin',
      userInfo: 'userInfo',
      siteConfig: 'siteConfig'
    }),
    loginDisable () {
      return Object.keys(this.loginInfo).some(item => this.loginInfo[item].length < this.lengthMap[item])
    },
    regDisable () {
      return Object.keys(this.regInfo).some(item => this.regInfo[item].length < this.lengthMap[item])
    },
    postSwitch () {
      return this.siteConfig.config && this.siteConfig.config.addTopicSwitch === '1'
    }
  },

  watch: {},

  created () {
  },

  methods: {
    goPost () {
      if (!this.postSwitch) {
        this.$alert({
          message: '系统维护中，发帖功能暂时关闭',
          okText: '确定'
        }).then(() => {
        })
        return
      }
      this.$router.replace({
        name: 'userCenter_editPost'
      })
    },
    refreshCode (eventName) {
      this.verifyCode = VERIFY_CODE + '?_ts=' + new Date().getTime()
      this[`${eventName}Info`].checkCode = ''
    },

    tapEvent (eventName) {
      this.$loading.show()
      this.$server.fetch(eventName, this[`${eventName}Info`]).then(res => {
        this.$loading.hide()
        this.$store.commit(this.$mutationType.UPDATE_USERINFO, res)
        this.$toast(eventName === 'login' ? '登录成功' : '注册成功')
      }).catch(err => {
        this.$loading.hide()
        this.$toast(err.message)
        this.refreshCode(eventName)
      })
    },

    logout () {
      this.$confirm('确认退出？').then(action => {
        if (action === 'ok') {
          this.$loading.show()
          this.$server.fetch('logout').then(res => {
            this.$loading.hide()
            this.$store.dispatch('clearUserInfo')
            this.$toast('退出成功')
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .p-user-center {
    position: relative;
    background-color: $white;
    .g-header {
      position: relative;
      > img {
        width: 100%;
        height: 3rem;
      }
      .avatar {
        position: relative;
        top: -.8rem;
        text-align: center;
        .m-base-img {
          background-color: $white;
          width: 1.6rem;
          height: 1.6rem;
          border-radius: .2rem;
          overflow: hidden;
          margin: auto;
          box-shadow: 0 .02rem .3rem rgba(162, 162, 162, 0.5);
        }
        .name {
          font-size: .3rem;
          margin-top: .2rem;
        }
      }
      .btns {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        font-size: .32rem;
        .btn {
          position: relative;
          display: inline-block;
          width: 50%;
          height: .8rem;
          text-align: center;
          color: $text-light;
          &.active {
            color: $white;
            &:after {
              content: '';
              @include set-center(h);
              bottom: 0;
              border: .22rem solid transparent;
              border-bottom-width: .28rem;
              border-bottom-color: $white;
            }
          }
        }
      }
    }
    .g-content {
      .u-forms {
        .title {
          width: 1.4rem;
          padding-left: .3rem;
        }
      }
      .user-list {
        .box {
          @extend %u-flex-box;
          height: .84rem;
          margin: .28rem;
          margin-top: 0;
          padding: 0 .16rem;
          border: 1px solid;
          border-radius: .12rem;
          font-size: .28rem;
          .iconfont {
            display: inline-block;
            font-size: .36rem;
            width: .4rem;
            text-align: center;
          }
          .text {
            @extend %u-flex-item;
            padding-left: .14rem;
          }
        }
      }
    }

    .m-site-footer {
      bottom: .98rem;
    }

  }
</style>
