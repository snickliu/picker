import Vue from 'vue'
import App from './App.vue'
import router from './router'
import routerGuide from './router/guide'
import store from './store'

import server from './server'

import mutationType from 'SRC/store/mutation-types'

// import './pwa/registerServiceWorker'

import { viewport, preventUserScale } from 'LIB'

import Loading from 'COMPONENTS/Loading'
import Toast from 'COMPONENTS/Toast'
import { Alert, Confirm } from 'COMPONENTS/Dialog'

import KsHeader from 'UI/Header'
import SiteFooter from 'UI/SiteFooter'
import BaseImage from 'COMPONENTS/BaseImage'

Vue.config.productionTip = false
Vue.use(preventUserScale)
viewport.init()

Vue.component('SiteFooter', SiteFooter)
Vue.component('KsHeader', KsHeader)
Vue.component('BaseImage', BaseImage)

Vue.prototype.$server = server
Vue.prototype.$loading = Loading
Vue.prototype.$toast = Toast
Vue.prototype.$alert = Alert
Vue.prototype.$confirm = Confirm

Vue.prototype.$mutationType = mutationType

// 守卫监听
routerGuide.watch(router)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
