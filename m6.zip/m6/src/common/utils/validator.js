/* eslint-disable prefer-promise-reject-errors */
const rules = {
  required: /\S/,
  userName: /^([A-Z]|[a-z]|[0-9]|_){6,16}$/,
  regName: /^([A-Z]|[a-z]|[0-9]|_){6,16}$/,
  password: /^([A-Z]|[a-z]|[0-9]|_){6,}$/,
  loginPassword: /^([A-Z]|[a-z]|[0-9]|_){6,}$/,
  qq: /^[1-9]\d{4,9}$/,
  captcha: /^[0-9]{4}$/,
  email: /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/,
  tel: /^1\d{10}$/,
  fundsPassword: /^\d{6}$/,
  bankCardNo: /\d{1,20}$/,
  invitationCode: /^([A-Z]|[a-z]|[0-9]){0,}$/
}
const err = {
  required: '该项不能为空',
  userName: '6-16之间，由字母/数字/下划线组成',
  regName: '6-16之间，由字母/数字/下划线组成',
  password: '密码长度为6位以上，由数字/字母/下划线组成',
  loginPassword: '密码长度为6位以上，由字母/数字/下划线组成',
  qq: '最少5位纯数字号码',
  email: '请输入邮箱号码',
  tel: '请输入手机号码',
  captcha: '请输入4位数字的验证码',
  fundsPassword: '请输入6位数字资金密码',
  bankCardNo: '请输入正确的银行卡号',
  invitationCode: '邀请码为数字/数字字母混合'
}

// maxLength为0时，则无长度限制
const maxLength = {
  required: 0,
  userName: 16,
  password: 0,
  loginPassword: 0,
  qq: 0,
  email: 0,
  tel: 11,
  captcha: 4,
  fundsPassword: 6,
  bankCardNo: 20,
  invitationCode: 0
}

const validate = (arg, value) => {
  return new Promise((resolve, reject) => {
    // 如果不是必须的，并且没有值，就不做监测
    if (arg.indexOf('required') < 0 && !value) {
      resolve()
      return
    }
    arg.some((elem, index) => {
      if (rules[elem]) {
        if (!rules[elem].test(value)) {
          return reject({
            errType: elem,
            errMsg: err[elem]
          })
        }
        if (index + 1 === arg.length) {
          return resolve()
        }
      }
    })
  })
}

export {
  validate,
  maxLength
}
