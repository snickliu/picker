import { sun } from 'LIB'

export default (time, format = 'hh:mm:ss', textFormat = 'MM月DD日') => {
  const formatObj = sun(time, format)
  const daysFormToday = formatObj.daysFromToday
  const daysMap = {
    '-1': '昨天',
    '0': '今天',
    '1': '明天'
  }

  let text = ''
  if (daysFormToday > 1 || daysFormToday < -1) {
    text = sun(time, textFormat).date
  } else {
    text = daysMap[daysFormToday]
  }

  return {
    text: text,
    date: formatObj.date
  }
}
