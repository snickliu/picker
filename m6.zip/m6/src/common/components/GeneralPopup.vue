<template>
  <popup
    v-model="visible" :clikMaskClose="clikMaskClose" class="g-general">
    <div class="general-dialog">
      <header class="dialog-header" v-show="title&&type!='image'">{{title}}</header>
      <span class="close" :class="styleType[type]" @click="hide">
        <i class="iconfont icon-cancel"></i>
      </span>
      <div class="content" v-show="conent&&type!='image'"  v-html="conent">
      </div>
      <div @click="submit">
        <BaseImage v-show="imgUrl" :defaultSrc="require('IMAGES/default/postlist03.png')" :imgSrc="imgUrl"/>
      </div>
      <div class="dialog-footer" v-show="buttonText&&type!='image'">
        <span
          class="button"
          @click="submit">
          {{buttonText}}
        </span>
      </div>
    </div>
  </popup>
</template>

<script>
import Popup from './Popup.vue'

export default {
  name: '',

  model: {
    prop: 'serviceVisible',
    event: 'changeVisible'
  },

  props: {
    type: String,
    imgUrl: String,
    title: String,
    serviceVisible: Boolean,
    clikMaskClose: {
      type: Boolean,
      default: true
    },
    buttonText: String,
    conent: String
  },
  computed: {
  },

  components: {
    Popup
  },

  data () {
    return {
      visible: this.serviceVisible,
      styleType: {
        'text': 'text-close',
        'image': 'img-close',
        'other': ''
      }
    }
  },

  created () {
    console.log(this.conent)
  },

  watch: {
    visible (visible) {
      this.$emit('changeVisible', visible)
    },

    serviceVisible (visible) {
      this.visible = visible
    }
  },

  methods: {
    submit () {
      this.$emit('btnHandling', this.visible)
    },
    hide () {
      this.visible = false
    }
  }
}
</script>

<style lang="scss" scoped>
  .g-general {
    .general-dialog{
      .m-img {
        width: inherit;
      }
      background: $white;
      font-size: .34rem;
      width: 6rem;
      .dialog-header {
        height: .8rem;
        line-height: .8rem;
        color: $white;
        background: $theme;
        text-align: center;
      }
      .close {
        background-color: $white;
        width: 0.64rem;
        height: 0.48rem;
        position: absolute;
        right: 0;
        top: 0;
        text-align: center;
        border-radius: 0 0 0 5rem;
        i {
          margin-left: 0.1rem;
          color:  $theme;
        }
      }
      .text-close {
        background-color: $white;
        i {
          color:  $theme;
        }
      }
      .img-close {
        background-color: $theme;
        z-index: 100;
        i {
          color:  $white;
        }
      }
      .content {
        padding: .2rem;
        text-indent: 0.6rem;
        overflow: hidden;
        margin-right: 0.2rem;
      }
      .big-img {
        height: 4.26rem;
        width: 5.68rem;
      }
      .dialog-footer {
        @extend %u-flex-box;
        @include border-1px($bd-main, top);
        height: .9rem;
        .button {
          @extend %u-flex-item;
          text-align: center;
          color: $theme;
          font-size: .34rem;
          line-height: .66rem;
        }
      }
    }
  }

</style>
