import Slider from './Slider.vue'
import SliderItem from './SliderItem.vue'
export {
  Slider,
  SliderItem
}
