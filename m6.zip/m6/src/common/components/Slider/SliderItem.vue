<template>
  <div class="slider-item" :style="style" @click="goInfo">
    <slot></slot>
  </div>
</template>

<script>

export default {
  name: 'SliderItem',
  props: {
    info: {
      type: Object,
      default () {
        return {}
      }
    }
  },
  data () {
    return {
      offset: 0
    }
  },
  created () {
  },

  computed: {
    style () {
      return {
        width: this.$parent.width + 'px',
        transform: `translate(${this.offset}px, 0)`
      }
    }
  },
  methods: {
    goInfo () {
      this.$emit('goInfo', this.info)
    }
  },

  beforeCreate () {
    this.$parent.swipes.push(this)
  },

  destroyed () {
    this.$parent.swipes.splice(this.$parent.swipes.indexOf(this), 1)
  }
}
</script>
