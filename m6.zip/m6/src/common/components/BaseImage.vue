<template>
  <div class="m-base-img">
    <p class="loading" v-if="showLoading && !showImg">
      <i class="iconfont icon-loding c-text"></i>
    </p>
    <img :src="src"
         :alt="imgAlt"
         class="m-img"
         :class="{'full': full}"
         v-show="showImg"
         @error="imgError"
         @load="loadedImg">
  </div>
</template>

<script>
import defaultSrc from 'IMAGES/default/adv.png'

export default {
  name: 'BaseImage',

  props: {
    imgSrc: String,
    defaultSrc: {
      type: String,
      default: defaultSrc
    },
    imgAlt: {
      type: String,
      default: '图片'
    },
    showLoading: {
      type: Boolean,
      default: false
    },
    full: {
      type: Boolean,
      default: false
    }
  },

  data () {
    return {
      src: this.imgSrc || this.defaultSrc,
      showImg: false
    }
  },

  watch: {
    imgSrc () {
      if (this.showLoading) {
        this.showImg = false
      }
      this.src = this.imgSrc
    }
  },

  created () {
  },

  methods: {
    loadedImg () {
      this.showImg = true
    },

    imgError ($event) {
      this.src = this.defaultSrc
      $event.target.onerror = null
    }
  }
}
</script>

<style lang="scss">
  .m-base-img {
    position: relative;
    height: auto;
    // background-color: $white;
    .loading {
      @include set-center();
      .iconfont {
        font-size: 40px;
        text-align: center;
        display: block;
        width: 44px;
        height: 44px;
        margin-bottom: 0;
        opacity: .5;

        animation: circle 1.5s infinite linear;
        transform-origin: center center;

        @keyframes circle {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: rotate(360deg);
          }
        }
      }
    }
    .m-img {
      width: -webkit-fill-available;
      &.full {
        width: 100%;
        height: 100%;
      }
    }
  }
</style>
