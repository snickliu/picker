<template>
  <transition :name="transition">
    <div class="m-popup" v-show="value">
      <div
      class="mask"
      :style="{'opacity': maskOpacity}"
      @click.stop="hide" v-show="mask">
      </div>

      <!-- center popup -->
      <div v-if="pos === 'center'" class="center-wrap">
        <div class="center-mask" @click.stop="hide"></div>
        <div class="content content-center">
          <slot></slot>
        </div>
      </div>

      <!-- others -->
      <div v-else class="content" :class="`content-${pos}`">
        <slot></slot>
      </div>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'Popup',

  props: {
    value: Boolean,
    pos: {
      type: String,
      default: 'center'
    },
    mask: {
      type: Boolean,
      default: true
    },
    clikMaskClose: {
      type: Boolean,
      default: true
    },
    transition: {
      type: String,
      default: 'popup-show'
    },
    maskOpacity: {
      type: Number,
      default: 0.3
    }
  },

  methods: {
    hide () {
      this.clikMaskClose && this.$emit('input', false)
    }
  }
}
</script>
<style lang="scss" scoped>
  .m-popup {
    position: fixed;
    z-index: 2000;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    .mask {
      position: absolute;
      height: 100%;
      width: 100%;
      top: 0;
      left: 0;
      background-color: $black;
    }
    .center-mask, .center-wrap{
      position: absolute;
      height: 100%;
      width: 100%;
    }
    .content {
      position: absolute;
      &-center {
        left: 0;
        @include set-center();
        border-radius: .1rem;
      }
      &-bottom {
        width: 100%;
        bottom: 0;
        left: 0;
      }
      &-top {
        width: 100%;
        top: 0;
        left: 0;
      }
      &-full {
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
      }
      &-right {
        height: 100%;
        right: 0;
      }
    }
  }
</style>
