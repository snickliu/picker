<template>
  <transition name="fade">
    <div class="m-up-arrow" v-show="arrowVisible" @click="goTop">
      <i class="iconfont icon-up"></i>
    </div>
  </transition>
</template>

<script>
export default {
  name: '',

  components: {},

  data () {
    return {
      scrollTop: 0,
      targetNode: null
    }
  },

  computed: {
    arrowVisible () {
      return this.scrollTop > parseInt(window.innerHeight) / 2
    }
  },

  created () {
    this.init()
  },

  activated () {
    this.init()
  },

  methods: {
    init () {
      // this.scrollTop = 0
      this.$nextTick(() => {
        this.targetNode = this.$el.parentNode
        this.targetNode.addEventListener('scroll', this.scrollEvent)
      })
    },

    scrollEvent () {
      this.scrollTop = this.targetNode.scrollTop
    },

    goTop () {
      let timer = null
      const time = 100
      const stepTime = 10
      const step = this.scrollTop / time * stepTime
      const goStep = () => {
        timer = setTimeout(() => {
          this.targetNode.scrollTop = this.targetNode.scrollTop - step
          if (this.targetNode.scrollTop > 0) {
            goStep()
          } else {
            clearTimeout(timer)
            timer = null
          }
        }, stepTime, this)
      }

      goStep()
    }
  },

  deactivated () {
    this.targetNode.removeEventListener('scroll', this.scrollEvent)
  }
}
</script>

<style lang="scss" scoped>
  .m-up-arrow {
    position: fixed;
    bottom: 1.4rem;
    right: .3rem;
    width: 1rem;
    height: 1rem;
    text-align: center;
    line-height: 1rem;
    background-color: $white;
    border-radius: 50%;
    box-shadow: 0 1px 11px rgba(0, 0, 0, 0.23);
    .iconfont {
      font-size: .52rem;
      color: $text-sub;
    }
  }
</style>
