<template>
  <Popup
    v-model="visible"
    :mask="showMask"
    :clikMaskClose="!hasButton"
    :transition="transition"
    class="m-dialog">
    <div v-show="hasTitle" class="dialog-title">{{title || dialogTitle}}</div>
    <div class="dialog-content" :class="{'has-title': hasTitle}">
      <slot></slot>
      <div class="dialog-message" v-show="message" v-html="message"></div>
    </div>
    <div class="dialog-footer" v-show="hasButton">
      <span
        v-show="type === 'confirm'"
        class="button cancel"
        :class="{'link': !title}"
        @click="hide('cancel')">
        {{dialogButtonText ? dialogButtonText.cancel : cancelText}}
      </span>
      <span
        class="button"
        @click="hide('ok')">
        {{dialogButtonText ? dialogButtonText.ok : okText}}
      </span>
    </div>
  </Popup>
</template>
<script>
import Popup from '../Popup.vue'

export default {
  name: 'Dialog',

  components: {
    Popup
  },

  props: {
    hasButton: {
      type: Boolean,
      default: true
    },
    transition: String,
    dialogTitle: String,
    dialogButtonText: Object
  },

  data () {
    return {
      visible: false,
      showMask: true,
      type: 'dialog',

      defaultButtonText: {
        ok: '确定',
        cancel: '取消'
      },
      buttonText: '我知道了',

      okText: '',
      cancelText: '',

      title: '',
      message: ''
    }
  },

  computed: {
    hasTitle () {
      return !!this.title || !!this.dialogTitle
    }
  },

  methods: {
    show (options) {
      this.title = options.title
      this.message = options.message
      this.type = options.type || 'dialog'
      this.okText = options.okText || (options.type === 'confirm' ? this.defaultButtonText.ok : this.buttonText)
      this.cancelText = options.cancelText || this.defaultButtonText.cancel
      this.visible = true
    },

    hide (type) {
      this.visible = false
      this.$emit('hide', type)
    }
  }
}
</script>
<style lang="scss">
  .m-dialog {
    .content {
      width: 80%;
      background-color: $white;
      .dialog-title {
        text-align: center;
        font-size: .34rem;
        background-color: $theme;
        color: $white;
        line-height: 0.8rem;
        border-radius: .1rem .1rem 0 0;
      }
      .dialog-content {
        padding: .6rem .3rem;
        font-size: 0.3rem;
        text-align: center;
        &.has-title {
          padding: .8rem .3rem;
        }
      }
      .dialog-footer {
        @extend %u-flex-box;
        @include border-1px($bd-main, top);
        height: .9rem;
        .button {
          @extend %u-flex-item;
          text-align: center;
          color: $theme;
          font-size: .34rem;
          line-height: .66rem;
          &.cancel {
            @include border-1px($bd-main, right);
            color: $text-sub;
            &.link {
              color: $link;
            }
          }
        }
      }
    }
  }
</style>
