<template>
  <div
    class="g-marquee"
    :style="marqueeStyle"
  >
    <div class="left" v-if="$slots.left">
      <slot name="left"></slot>
    </div>
    <div class="content-wrap" ref="contentWrap">
      <p
        ref="content"
        class="content"
        :class="animationClass"
        :style="contentStyle"
        @animationend="onAnimationEnd"
        @webkitAnimationEnd="onAnimationEnd"
      >
        <slot>{{ text }}</slot>
      </p>
    </div>
    <div class="right" v-if="$slots.right">
      <slot name="right"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Marquee',

  props: {
    text: String,
    color: String,
    backgroundColor: String,
    delay: {
      type: [String, Number],
      default: 1
    },
    speed: {
      type: Number,
      default: 50
    }
  },
  data () {
    return {
      wrapWidth: 0,
      firstRound: true,
      duration: 0,
      offsetWidth: 0,
      showNoticeBar: true,
      animationClass: ''
    }
  },
  computed: {
    marqueeStyle () {
      return {
        color: this.color,
        background: this.backgroundColor
      }
    },
    contentStyle () {
      return {
        paddingLeft: this.firstRound ? 0 : this.wrapWidth + 'px',
        animationDelay: (this.firstRound ? this.delay : 0) + 's',
        animationDuration: this.duration + 's'
      }
    }
  },
  mounted () {
    this.initAnimation()
  },

  watch: {
    text: function () {
      this.$nextTick(this.initAnimation)
    }
  },

  methods: {
    onAnimationEnd () {
      this.firstRound = false
      this.$nextTick(() => {
        this.duration = (this.offsetWidth + this.wrapWidth) / this.speed
        this.animationClass = 'play-infinite'
      })
    },
    initAnimation () {
      const offsetWidth = this.$refs.content.getBoundingClientRect().width
      const wrapWidth = this.$refs.contentWrap.getBoundingClientRect().width
      if (offsetWidth > wrapWidth) {
        this.wrapWidth = wrapWidth
        this.offsetWidth = offsetWidth
        this.duration = offsetWidth / this.speed
        this.animationClass = 'play'
      }
    }
  }
}
</script>
<style lang="scss">
.g-marquee{
  display: -webkit-flex;
  display: flex;
  justify-content: center;
  height: 30px;
  line-height: 30px;
  .play {
    animation: marquee-play linear both;
  }

  .play-infinite {
    animation: marquee-play-infinite linear infinite both;
  }

  .left, .right{
    padding: 0 10px;
  }
  .content-wrap{
    overflow: hidden;
    width: 100%;
    position: relative;
    flex: 1;
    .content{
      white-space: nowrap;
      position: absolute;
    }
  }

}

@keyframes marquee-play {
  to { transform: translate3d(-100%, 0, 0) }
}
@keyframes marquee-play-infinite {
  to { transform: translate3d(-100%, 0, 0) }
}
</style>
