import Tab from './Tab.vue'
import TabItem from './TabItem.vue'

export {
  Tab,
  TabItem
}
