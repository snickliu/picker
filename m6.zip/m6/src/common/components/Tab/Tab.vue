<template>
  <div
    ref="tab"
    class="m-tab">
    <div
      class="tab-wrap"
      ref="tab-wrap"
      :style="wrapStyle">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll'

export default {
  name: 'Tab',
  model: {
    prop: 'activeItemIndex',
    event: 'updateActiveItemIndex'
  },
  props: {
    activeItemIndex: {
      type: Number,
      default: 0
    },
    activeClass: {
      type: String,
      default: 'tab-active'
    }
  },
  data () {
    return {
      scroller: null,
      items: [],
      scrollerOptions: {
        scrollX: true,
        scrollY: false,
        click: true,
        bounce: false
      },

      tabWidth: 0,
      wrapWidth: 0
    }
  },

  computed: {
    wrapStyle () {
      return {
        width: this.wrapWidth + 'px'
      }
    }
  },

  mounted () {
    this.scroller = new BScroll(this.$refs['tab'], this.scrollerOptions)
    this.tabWidth = this.$refs['tab'].getBoundingClientRect().width
  },

  methods: {
    initItem (item) {
      this.wrapWidth += item.width
      this.items.push(item)
      return {
        index: this.items.length,
        activeClass: this.activeClass
      }
    },

    refresh () {
      this.items = []
      this.wrapWidth = 0
      this.$nextTick(() => {
        setTimeout(() => {
          this.scroller.scrollTo(0, 0, 1)
          this.scroller.refresh()
        }, 100)
      })
    },

    itemOnTap (index) {
      this.$emit('updateActiveItemIndex', index)
      let distance = 0
      this.items.some((item, i) => {
        if (index > i) {
          distance += item.width
        } else {
          return true
        }
      })
      this.distance = distance
      if (this.wrapWidth <= this.tabWidth) {
        return
      }

      // 移动到中间
      distance -= this.tabWidth / 2 - this.items[index].width / 2

      // 滚动容错
      distance = Math.max(0, distance)
      distance = Math.min(this.wrapWidth - this.tabWidth, distance)
      this.scroller.scrollTo(-distance, 0, 300, 'swipe')
    }
  }
}
</script>
<style lang="scss">
  .m-tab {
    position: relative;
    width: 100%;
    overflow: hidden;
    .tab-wrap {
      display: flex;
      overflow: hidden;
      min-width: 100%;
      .tab-item {
        flex-shrink: 0;
        flex-grow: 0;
        flex-basis: auto;
      }
    }
  }

</style>
