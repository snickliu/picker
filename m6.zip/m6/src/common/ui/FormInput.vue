<template>
  <div class="m-form-input">
    <slot></slot>
    <div class="m-input">
      <template v-if="isInput">
        <input
          ref="input"
          class="input"
          v-model.trim="inputValue"
          :type="inputType"
          @blur="blurEvent"
          @focus="focusEvent"
          :placeholder="placeholder">
        <i
          v-if="type === 'password'"
          class="eyes iconfont"
          :class="showPassword ? 'icon-eye' : 'icon-openeyes'"
          @click="clickEyes"
        ></i>
      </template>
      <template v-else>{{value}}</template>
    </div>
    <i
      v-if="isInput"
      class="close iconfont icon-fulldelete"
      v-show="!!inputValue.length"
      @click="inputValue = ''"
    ></i>
  </div>
</template>

<script>
import { validate, maxLength } from 'UTILS/validator'

export default {
  name: 'FormInput',

  components: {},

  props: {
    value: {
      type: String,
      defalut: ''
    },
    type: {
      type: String,
      default: 'text'
    },
    placeholder: {
      type: String,
      default: ''
    },
    verify: {
      type: Array,
      default () {
        return []
      }
    }
  },

  data () {
    return {
      inputValue: this.value,
      inputType: this.type,
      showPassword: this.type !== 'password'
    }
  },

  computed: {
    isInput () {
      return this.type !== 'div'
    }
  },

  mounted () {
    this.initMaxLength()
    this.checkValue()
  },

  watch: {
    value (value) {
      this.inputValue = value
    },
    inputValue (inputValue) {
      this.$emit('input', inputValue)
      this.checkValue()
    }
  },

  methods: {
    blurEvent () {
      validate(this.verify, this.inputValue)
        .then(() => {
          this.$emit('blurEvent', 'ok')
        })
        .catch(({ errType, errMsg }) => this.$emit('blurEvent', { status: 'no', errType, errMsg }))
    },
    focusEvent () {
      this.$emit('focusEvent')
    },
    initMaxLength () {
      if (this.verify.length) {
        const max = Math.max.apply(null, this.verify.map(item => maxLength[item]))
        max > 0 && this.$refs.input.setAttribute('maxlength', max)
      }
    },
    checkValue () {
      if (!(this.verify.length)) return

      validate(this.verify, this.inputValue)
        .then(() => {
          this.handler('ok')
        })
        .catch(({ errType, errMsg }) => this.handler('no', errType, errMsg))
    },
    handler (status, errType, errMsg) {
      this.$emit('validator', { status, errType, errMsg })
    },
    clickEyes () {
      this.showPassword = !this.showPassword
      this.inputType = this.showPassword ? 'text' : 'password'
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-form-input {
    @extend %u-flex-box;
    padding: .2rem;
    font-size: .32rem;
    .m-input {
      position: relative;
      padding-left: .2rem;
      @extend %u-flex-item;
      .input {
        width: 92%;
        min-height: .4rem;
        &::placeholder {
          color: $text-light;
        }
      }
      .eyes {
        right: 0;
        @include set-center(v);
        font-size: .44rem;
      }
    }
    .close {
      margin-left: .2rem;
      font-size: .36rem;
      border-radius: 50%;
    }
  }
</style>
