<template>
  <div class="m-button c-bg" :class="{'disable': disable}" @click="onTap">
    <slot/>
  </div>
</template>

<script>
export default {
  name: '',

  props: {
    disable: {
      type: Boolean,
      default: true
    }
  },

  components: {},

  data () {
    return {}
  },

  created () {
  },

  methods: {
    onTap () {
      if (this.disable) {
        return
      }

      this.$emit('onTap')
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-button {
    margin: .3rem;
    text-align: center;
    color: $white;
    font-size: .3rem;
    line-height: .8rem;
    border-radius: .12rem;
    &.disable {
      opacity: .6;
    }
  }
</style>
