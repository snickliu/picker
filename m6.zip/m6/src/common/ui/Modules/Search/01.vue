<template>
  <div class="m-search-01 u-module-chunk">
    <input type="text" class="input" v-model="value" placeholder='快速找高手-试试输入"平特一肖"'>
    <i class="iconfont c-bg icon-search" @click="jumpToList"></i>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},

  data () {
    return {
      value: ''
    }
  },

  created () {
  },

  methods: {
    jumpToList () {
      this.$router.push({
        path: '/home/postList',
        query: {
          search: this.value
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-search-01 {
    @extend %u-flex-box;
    line-height: .72rem;
    .input {
      @extend %u-flex-item;
      padding: 0 .24rem;
      font-size: .28rem;
      &::placeholder {
        color: $text-light;
      }
    }
    .iconfont {
      width: 1.1rem;
      text-align: center;
      color: $white;
      font-size: .36rem;
    }
  }
</style>
