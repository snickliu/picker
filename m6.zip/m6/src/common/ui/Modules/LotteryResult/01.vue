<template>
  <div class="m-lottery-result-01 u-module-chunk">
    <p class="line">六合彩开奖直播 <span class="c-text">090</span> 期开奖结果</p>
    <div class="lottery-result">
      <div class="ball-box" v-for="(num, index) in prizeNumber.split(',').slice(0, -1)" :key="index">
        <b :class="`ball ball-${numberMap[num].color}`">{{num}}</b>
        <p>{{numberMap[num].zodiac}}<span class="split">/</span>{{numberMap[num].wuXing}}</p>
      </div>
      <div class="ball-box">
        <span class="icon">+</span>
      </div>
      <div class="ball-box">
        <b :class="`ball ball-${numberMap[prizeNumber.substr(-2)].color}`">{{prizeNumber.substr(-2)}}</b>
        <p>{{numberMap[prizeNumber.substr(-2)].zodiac}}<span
          class="split">/</span>{{numberMap[prizeNumber.substr(-2)].wuXing}}</p>
      </div>
    </div>
    <p class="line">第091期开奖时间：08月14日 星期二 21点23分</p>
    <p class="line">
      <span>【644开奖】</span>
      <span>【最快开奖】</span>
      <span>【手机开奖】</span>
      <span>【开奖记录】</span>
    </p>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: '',

  components: {},

  data () {
    return {
      prizeNumber: '01,04,34,49,33,25,39'
    }
  },

  computed: {
    ...mapGetters({
      numberMap: 'numberMap'
    })
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-lottery-result-01 {
    padding: .12rem .1rem;
    background-color: #434141;
    color: $white;
    .line {
      line-height: .38rem;
    }
    .lottery-result {
      @extend %u-flex-box;
      background-color: $white;
      border-radius: .1rem;
      padding: .06rem .1rem;
      margin: .12rem 0;
      .ball-box {
        height: 1.08rem;
        @extend %u-flex-item;
        color: $text-main;
        text-align: center;
        .icon {
          font-size: .6rem;
          color: $black;
        }
        .split {
          color: $text-light;
        }
        .ball {
          width: .6rem;
          height: .6rem;
          line-height: .6rem;
          font-size: .32rem;
        }
      }
    }
  }
</style>
