import LotteryResult01 from './01.vue'

export {
  LotteryResult01
}
