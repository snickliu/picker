<template>
  <div class="m-navbar-01">
    <router-link
      tag="div"
      class="nav-item"
      :class="{'c-text': index === curNavIndex}"
      v-for="(nav, index) in data.list"
      :to="nav.link"
      :key="index">
      {{nav.text}}
    </router-link>
  </div>
</template>

<script>
export default {
  name: '',

  props: {
    data: {
      type: Object,
      default () {
        return {}
      }
    }
  },

  components: {},

  data () {
    return {
      curNavIndex: 0
    }
  },

  created () {
  },

  methods: {
    goUrl () {

    }
  }
}
</script>

<style lang="scss" scoped>
  .m-navbar-01 {
    @extend %u-flex-box;
    flex-wrap: wrap;
    justify-content: flex-start;
    text-align: center;
    background-color: $white;
    line-height: .6rem;
    padding: .1rem 0;
    font-size: .28rem;
    .nav-item {
      width: 25%;
      display: block;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  }
</style>
