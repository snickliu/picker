<template>
  <div class="m-comment-total u-module-chunk" v-if="commentList.length">
    <div class="comment-title">
      <div class="count">
        <span class="c-text">{{commentTotalData.totalCount}}</span> 条评论
        <span class="c-text all" v-show="userId" @click="fetchCommentList()">全部</span>
      </div>
      <div class="type">
        <template v-for="(type, index) in typeList">
          <b class="str" :key="index" v-if="index !== 0">|</b>
          <span :key="type.text"
                :class="{'c-text': index === curTypeIndex}"
                @click="chooseType(index)">{{type.text}}</span>
        </template>
      </div>
    </div>
    <CommentList :list="commentList" :pageSize="pageSize" @selUser="fetchCommentList"/>
    <PageView v-model="page" :totalPage="commentTotalData.totalPage"/>
  </div>
</template>

<script>
import eventHub from 'LIB/eventHub'
import CommentList from '../PartUtils/CommentList'
import PageView from '../PartUtils/PageView'
import { mapGetters } from 'vuex'

export default {
  name: '',

  components: {
    CommentList,
    PageView
  },

  data () {
    return {
      curTypeIndex: 0,
      typeList: [{
        text: '最新',
        orderBy: 'newest'
      }, {
        text: '最早',
        orderBy: 'earliest'
      }, {
        text: '最热',
        orderBy: 'hottest'
      }],
      userId: 0,
      page: 1,
      pageSize: 6
    }
  },

  computed: {
    ...mapGetters({
      commentData: 'commentData'
    }),

    commentTotalData () {
      const total = this.commentData.total
      if (!total) {
        return {}
      }
      return total.data
    },

    commentList () {
      return this.commentTotalData.list || []
    }
  },

  created () {
    this.fetchCommentList()
  },

  watch: {
    page () {
      this.fetchCommentList()
    }
  },

  methods: {
    chooseType (index) {
      this.curTypeIndex = index
      this.page = 1
      this.fetchCommentList()
    },

    fetchCommentList (userId = 0) {
      this.userId = Number(userId)
      eventHub.publish('fetchCommentData', [{
        postId: this.$route.query.postId || 0,
        userId: this.userId,
        orderBy: this.typeList[this.curTypeIndex].orderBy,
        page: this.page,
        size: this.pageSize
      }, 'total'])
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-comment-total {
    .comment-title {
      @include border-1px($bd-main, bottom);
      @extend %u-flex-box;
      padding: .2rem;
      .count {
        @extend %u-flex-item;
        .all {
          margin-left: .3rem;
        }
      }
      .type {
        .str {
          margin: 0 .12rem;
          color: $text-assist;
          font-size: .26rem;
        }
      }
    }
  }
</style>
