<template>
  <div class="m-comment">
    <CommentTop class="u-module-chunk"/>
    <CommentContent class="u-module-chunk"/>
    <CommentTotal class="u-module-chunk"/>
  </div>
</template>

<script>
import CommentTop from './CommentTop.vue'
import CommentContent from './CommentContent.vue'
import CommentTotal from './CommentTotal.vue'

export default {
  name: '',

  components: {
    CommentTop,
    CommentContent,
    CommentTotal
  },

  data () {
    return {
    }
  },

  created () {
  },

  methods: {
  }
}
</script>

<style lang="scss" scoped>

</style>
