<template>
  <div class="m-quick-comment">
    <input @focus="checkLogin" class="input" type="text" v-model="value" placeholder="记住域名，有你更精彩！">
    <span class="btn c-bg" @click="publishComment">快速{{$route.name === 'home' ? '留言' : '评论'}}</span>
  </div>
</template>

<script>
import eventHub from 'LIB/eventHub'
import { mapGetters } from 'vuex'

export default {
  name: '',

  components: {},

  data () {
    return {
      value: ''
    }
  },

  computed: {
    ...mapGetters({
      commentData: 'commentData'
    })
  },

  created () {
  },

  methods: {
    checkLogin () {
      eventHub.publish('checkLogin')
    },

    publishComment () {
      if (!this.value) {
        return
      }

      this.$loading.show()
      this.$server.fetch('addComment', {
        content: this.value,
        postId: this.$route.query.postId || 0,
        commentId: 0
      }).then(() => {
        eventHub.publish('fetchCommentData', [this.commentData.total.param, 'total'])
        eventHub.publish('fetchCommentData', [this.commentData.top.param, 'top'])
        this.value = ''
        this.$loading.hide()
        this.$toast('发布成功')
      }).catch(err => {
        this.$loading.hide()
        this.$toast(err.message)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-quick-comment {
    @extend %u-flex-box;
    background-color: $bd-main;
    height: .88rem;
    padding: 0 .2rem;
    .input {
      @extend %u-flex-item;
      background-color: $white;
      height: .5rem;
      border-radius: .06rem;
      padding: 0 .12rem;
      &::placeholder {
        color: $text-light;
      }
    }
    .btn {
      color: $white;
      width: 1.24rem;
      line-height: .5rem;
      text-align: center;
      margin-left: .2rem;
      border-radius: .06rem;
    }
  }
</style>
