<template>
  <div class="m-comment-top u-module-chunk" v-if="commentList.length">
    <p class="u-module-title c-text"><i class="str c-bg"></i>被顶起的{{isHome ? '留言' : '评论'}}</p>
    <CommentList :pageSize="2" :list="commentList"/>
  </div>
</template>

<script>
import eventHub from 'LIB/eventHub'
import CommentList from '../PartUtils/CommentList'
import { mapGetters } from 'vuex'

export default {
  name: '',

  props: {
    userId: {
      type: Number,
      default: 0
    }
  },

  components: {
    CommentList
  },

  data () {
    return {}
  },

  computed: {
    ...mapGetters({
      commentData: 'commentData'
    }),

    isHome () {
      return this.$route.name === 'home'
    },

    postId () {
      return this.$route.query.postId || 0
    },

    commentList () {
      const top = this.commentData.top
      if (!top) {
        return []
      }
      return top.data.list.slice(0, 2)
    }
  },

  created () {
    eventHub.publish('fetchCommentData', [{
      postId: this.postId,
      userId: 0,
      orderBy: 'hottest'
    }, 'top'])
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
</style>
