<template>
  <div id="comment" class="m-comment-content u-module-chunk">
    <div class="comment-title">
      <div class="auth">
        <BaseImage :defaultSrc="require('IMAGES/avatar.png')"
                   :imgSrc="isLogin ? userInfo.avatar : require('IMAGES/avatar.png')"/>
        <span class="name">{{isLogin ? userInfo.userName : '未登录'}}</span>
      </div>
      <div class="type">
        <span @click="tapBtn('left')">{{ isLogin ? '更换头像' : '登录'}}</span>
        <b class="str">|</b>
        <span @click="tapBtn('right')">{{ isLogin ? '退出' : '免费注册'}}</span>
      </div>
    </div>
    <CommentBox/>
  </div>
</template>

<script>
import CommentBox from '../PartUtils/CommentBox.vue'
import { mapGetters } from 'vuex'

export default {
  name: '',

  components: {
    CommentBox
  },

  data () {
    return {}
  },

  computed: {
    ...mapGetters({
      isLogin: 'isLogin',
      userInfo: 'userInfo'
    })
  },

  created () {
  },

  methods: {
    tapBtn (aside) {
      if (this.isLogin) {
        if (aside === 'left') {
          this.$router.push({
            path: '/userCenter/modifyAvatar'
          })
        } else if (aside === 'right') {
          this.$confirm('确认退出？').then(action => {
            if (action === 'ok') {
              this.$loading.show()
              this.$server.fetch('logout').then(res => {
                this.$loading.hide()
                this.$store.dispatch('clearUserInfo')
                this.$toast('退出成功')
              })
            }
          })
        }
      } else {
        this.$router.push({
          path: '/userCenter',
          query: {
            type: aside === 'left' ? 'login' : aside === 'right' ? 'reg' : ''
          }
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-comment-content {
    .comment-title {
      @include border-1px($bd-main, bottom);
      @extend %u-flex-box;
      padding: .2rem;
      .auth {
        @extend %u-flex-item;
        .m-base-img {
          display: inline-block;
          width: .3rem;
          height: .3rem;
          border-radius: .1rem;
          margin-right: .12rem;
        }
      }
      .type {
        .str {
          margin: 0 .12rem;
          color: $text-assist;
          font-size: .26rem;
        }
      }
    }
  }
</style>
