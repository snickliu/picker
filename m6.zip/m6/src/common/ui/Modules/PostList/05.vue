<template>
  <div class="m-post-list-05 u-module-chunk">
    <Slider height="5.06rem">
      <SliderItem v-for="(item,i) in imgList" :key="i">
        <BaseImage :defaultSrc="require('IMAGES/default/postlist05.png')" :imgSrc="item.pic"/>
      </SliderItem>
    </Slider>
    <div class="list">
      <div class="item c-text" v-for="(item,i) in list" :key="i" @click="jumpToDetail(item, item.nickname)">
        <img class="u-icon-dazzle" src="~IMAGES/icons/hot.png" alt="">
        <span class="text-title" v-html="item.title"></span>
      </div>
    </div>
  </div>
</template>

<script>
import { Slider, SliderItem } from 'COMPONENTS/Slider'

export default {
  name: '',

  components: {
    Slider,
    SliderItem
  },
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      topicIdList: this.data.contentList,
      imgList: this.data.picList,
      list: this.data.topicList
    }
  },

  created () {
  },

  methods: {
    jumpToDetail (item, anchor = '') {
      if (item.linkUrl) {
        location.href = item.linkUrl
        return
      }
      this.$router.push({
        path: '/home/postDetail',
        query: {
          postId: item.id
        },
        hash: anchor
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-post-list-05 {
    .m-slider {
      margin: .12rem auto;
      width: 3.56rem;
    }
    .list {
      @include border-1px($bd-main, top);
      font-size: .28rem;
      .item {
        @include border-1px($bd-main, bottom);
        @include clear-border();
        @include line-overflow();
        padding: .18rem .12rem;
        padding-left: .3rem;
        .text-title{
          display: inline-block;
        }
      }
    }
  }
</style>
