<template>
  <div class="m-post-list-01 u-module-chunk">
    <BaseImage v-for="(item,i) in imgList" :key="i" :imgSrc="item.pic"/>
    <div class="list">
      <div class="item" v-for="(item,index) in list" :key="index" @click="jumpToDetail(item, item.nickname)">
        <div class="title c-text" v-html="item.title"></div>
        <span class="intro">{{item.nickname}}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      imgList: this.data.list,
      list: this.data.topicList
    }
  },

  created () {
  },

  methods: {
    jumpToDetail (item, anchor = '') {
      if (item.linkUrl) {
        location.href = item.linkUrl
        return
      }
      this.$router.push({
        path: '/home/postDetail',
        query: {
          postId: item.id
        },
        hash: anchor
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-post-list-01 {
    .list {
      .item {
        @include border-1px($bd-main, bottom);
        @include clear-border();
        @extend %u-flex-box;
        padding: .18rem .14rem;
        .title {
          @include line-overflow();
          @extend %u-flex-item;
          padding-right: .1rem;
        }
        .intro {
          @include line-overflow();
          color: $text-assist;
          width: 20%;
          text-align: right;
        }
      }
    }
  }
</style>
