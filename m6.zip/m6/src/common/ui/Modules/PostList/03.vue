<template>
  <div class="m-post-list-03 u-module-chunk">
    <div class="item" v-for="(item,i) in list" :key="i" @click="jumpToDetail(item, item.nickname)">
      <BaseImage  :defaultSrc="require('IMAGES/default/postlist03.png')" :imgSrc="imgList[i]?imgList[i].pic:''"/>
      <div class="content">
        <p v-html="item.title"></p>
        <div class="icon">
          <span class="c-text">解</span>
          <i class="iconfont icon-star" v-for="j in 5" :key="j"></i>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      imgList: this.data.list,
      list: this.data.topicList
    }
  },

  created () {
  },

  methods: {
    jumpToDetail (item, anchor = '') {
      if (item.linkUrl) {
        location.href = item.linkUrl
        return
      }
      this.$router.push({
        path: '/home/postDetail',
        query: {
          postId: item.id
        },
        hash: anchor
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-post-list-03 {
    .item {
      @extend %u-flex-box;
      @include border-1px($bd-main, bottom);
      @include clear-border();
      padding: .18rem .12rem;
      .m-base-img {
        width: 2.2rem;
        height: 1.5rem;
        background-color: $bg-main;
        margin-right: .4rem;
      }
      .content {
        position: relative;
        @extend %u-flex-item;
        height: 1.5rem;
        font-size: .28rem;
        .icon {
          position: absolute;
          left: 0;
          bottom: 0;
          .iconfont {
            color: $star;
            margin-left: .1rem;
            font-size: .28rem;
          }
        }
      }
    }
  }
</style>
