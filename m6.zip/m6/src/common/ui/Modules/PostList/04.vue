<template>
  <div class="m-post-list-04 u-module-chunk">
    <div class="list">
      <div class="item" v-for="(item,i) in imgList" :key="i">
        <BaseImage :defaultSrc="require('IMAGES/default/postlist03.png')" :imgSrc="item.pic"/>
        <div class="content">
          <div class="text c-text-all"  v-for="(itemT,index) in formatting(i)" :key="index" @click="jumpToDetail(itemT, itemT.nickname)">
           <span class="text-title" v-if="itemT" v-html="itemT.title"></span><i class="iconfont icon-star"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      imgList: this.data.list,
      list: this.data.topicList
    }
  },

  created () {
  },

  methods: {
    jumpToDetail (item, anchor = '') {
      if (item.linkUrl) {
        location.href = item.linkUrl
        return
      }
      this.$router.push({
        path: '/home/postDetail',
        query: {
          postId: item.id
        },
        hash: anchor
      })
    },
    formatting (index) {
      // debugger // eslint-disable-line
      let i = (index + 1) * 3
      let j = index * 3
      let data = []
      for (j; j < i; j++) {
        data.push(this.list[j])
      }
      return data
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-post-list-04 {
    .list {
      .item {
        @include border-1px($bd-main, bottom);
        @include clear-border();
        @extend %u-flex-box;
        .m-base-img {
          width: 2.48rem;
          height: 1.7rem;
          margin: .12rem;
          background-color: $bg-main;
        }
        .content {
          @extend %u-flex-item;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          .text {
            @include border-1px($bd-main, bottom);
            @include clear-border();
            @include line-overflow();
            line-height: .6rem;
            font-size: .26rem;
            margin-left: .1rem;
            .iconfont {
              font-size: .28rem;
              margin-left: .1rem;
            }
            .text-title{
              display: inline-block;
            }
          }
        }
      }
    }
  }
</style>
