<template>
  <div class="m-post-list-02 u-module-chunk">
    <BaseImage v-for="(item,i) in imgList" :key="i" :imgSrc="item.pic"/>
    <div class="list">
      <div class="item" v-for="(item,index) in list" :key="index" @click="jumpToDetail(item, item.nickname)">
        <span class="type c-bd c-text">{{item.topicTypeName}}</span>
        <div class="title" v-html="item.title"></div>
        <span class="auth">{{item.nickname}}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      imgList: this.data.list,
      list: this.data.topicList
    }
  },

  created () {
  },

  methods: {
    jumpToDetail (item, anchor = '') {
      if (item.linkUrl) {
        location.href = item.linkUrl
        return
      }
      this.$router.push({
        path: '/home/postDetail',
        query: {
          postId: item.id
        },
        hash: anchor
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-post-list-02 {
    .m-base-img {
      padding: .14rem;
    }
    .list {
      margin-top: .1rem;
      .item {
        @extend %u-flex-box;
        @include border-1px($bd-main, bottom);
        @include clear-border();
        padding: .18rem .12rem;
        font-size: .28rem;
        .type {
          font-size: .16rem;
          line-height: .26rem;
          padding: 0 .06rem;
          border-radius: .1rem;
          border: 1px solid;
          margin-right: .2rem;
        }
        .title {
          @extend %u-flex-item;
          @include line-overflow();
          color: $post-issue;
          > span {
            color: $post-title;
          }
        }
        .auth {
          @include line-overflow();
          color: $text-assist;
          width: 20%;
          text-align: right;
        }
      }
    }
  }
</style>
