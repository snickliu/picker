<template>
  <router-link
    tag="div"
    :to="img.link"
    class="m-image-ad-01"
    :defaultSrc="require('IMAGES/default/pic.png')"
    :imgSrc="img.pic"/>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      img: this.data.list[0]
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-image-ad-01 {
    margin: .3rem 0;
  }
</style>
