<template>
  <Slider class="m-image-ad-02">
    <SliderItem v-for="(item,i) in list" :key="i">
      <router-link class="c-text" :to="item.link">
        <BaseImage :defaultSrc="require('IMAGES/default/pic.png')" :imgSrc="item.pic" />
      </router-link>
    </SliderItem>
  </Slider>
</template>

<script>
import { Slider, SliderItem } from 'COMPONENTS/Slider'

export default {
  name: '',

  components: {
    Slider,
    SliderItem
  },
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      list: this.data.list
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-image-ad-02 {
    background-color: $white;
  }
</style>
