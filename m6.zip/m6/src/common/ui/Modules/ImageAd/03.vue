<template>
  <div class="m-image-ad-03 u-module-chunk">
    <p class="u-module-title c-text"><i class="str c-bg"></i>推荐</p>
    <Tab v-model="curTabIndex">
      <TabItem v-for="(item,i) in list" :key="i">
        <div class="item" @click="showDetail(item.pic)" >
          <BaseImage :defaultSrc="require('IMAGES/default/postlist03.png')" :imgSrc="item.pic"/>
          <p>{{item.text}}</p>
        </div>
      </TabItem>
    </Tab>
    <GeneralPopup
      :type="'image'"
      :imgUrl="imgUrl"
      v-model="dialogShow">
    </GeneralPopup>
  </div>
</template>

<script>
import { Tab, TabItem } from 'COMPONENTS/Tab'
import GeneralPopup from 'COMPONENTS/GeneralPopup'

export default {
  name: '',

  components: {
    Tab,
    TabItem,
    GeneralPopup
  },
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      curTabIndex: -1,
      dialogShow: false,
      list: this.data.list,
      imgUrl: ''
    }
  },

  created () {
  },

  methods: {
    showDetail (url) {
      // debugger // eslint-disable-line
      this.imgUrl = url
      this.dialogShow = true
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-image-ad-03 {
    position: relative;
    .m-tab {
      padding-top: .3rem;
      .tab-item {
        width: 3.4rem;
        padding: 0 .18rem;
        text-align: center;
        &.tab-active {
          border-bottom: none !important;
        }
        .item {
          width: 2.96rem;
          padding: .12rem;
          margin-bottom: .4rem;
          border-radius: .1rem;
          box-shadow: 0 .2rem .3rem rgba(108, 108, 108, 0.4);
          .m-base-img {
            height: 1.88rem;
            background-color: $bg-main;
            margin-bottom: .12rem;
          }
        }
      }
    }
  }
</style>
