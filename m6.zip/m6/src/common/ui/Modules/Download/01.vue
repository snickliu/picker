<template>
  <div class="m-download-01 u-module-chunk">
    <p class="text" v-html="down.utext"></p>
    <router-link class="btn c-bg" :to="down.link">{{down.text}}</router-link>
  </div>
</template>

<script>
export default {
  name: '',

  props: {
    data: Object,
    default () {
      return {}
    }
  },

  components: {},

  data () {
    return {
      down: this.data.list[0]
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-download-01 {
    position: relative;
    overflow: visible;
    margin-bottom: .7rem;
    .text {
      font-size: .42rem;
      color: $text-sub;
      padding: .5rem;
      padding-bottom: .8rem;
      text-align: center;
      word-break: break-all;
    }
    .btn {
      @include set-center(h);
      bottom: -.4rem;
      color: $white;
      width: 80%;
      line-height: .88rem;
      text-align: center;
      border-radius: 1rem;
      font-size: .32rem;
    }
  }
</style>
