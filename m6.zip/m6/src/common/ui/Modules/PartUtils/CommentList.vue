<template>
  <div class="m-comment-list">
    <div class="comment-item" v-for="(item, index) in list" :key="index">
      <div class="u-post-auth" @click="selUserCommentList(item.userId)">
        <BaseImage :defaultSrc="require('IMAGES/avatar.png')" :imgSrc="item.avatar"/>
        <div class="auth">
          <span class="name">{{item.nickname}}</span>
          <p class="date">{{item.createTimeStamp}}</p>
        </div>
        <div class="remark">
          <span class="u-comment" @click="setLike(item)">
            <i class="iconfont" :class="item.isUp ? 'c-text icon-like' : 'icon-like-line'"></i>
            顶 {{item.upCount}}
          </span>
        </div>
      </div>
      <pre class="content" v-html="item.content"></pre>
      <CommentBox type="inside" :commentId="item.id" :isOwner="item.isOwner"/>
      <FeedbackList :list="item.replyList"/>
    </div>
  </div>
</template>

<script>
import FeedbackList from './FeedbackList.vue'
import CommentBox from './CommentBox.vue'

export default {
  name: '',

  props: {
    pageSize: {
      type: Number,
      default: 6
    },

    list: {
      type: Array,
      default () {
        return []
      }
    }
  },

  components: {
    CommentBox,
    FeedbackList
  },

  data () {
    return {}
  },

  computed: {},

  created () {
  },

  methods: {
    selUserCommentList (userId) {
      this.$emit('selUser', userId)
    },

    setLike (item) {
      if (item.isUp) {
        return
      }

      const count = item.upCount
      this.$server.fetch('likeComment', {
        commentId: item.id
      }).then(res => {
        this.$set(item, 'isUp', 1)
        this.$set(item, 'upCount', count + 1)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-comment-list {
    .comment-item {
      @include border-1px($bd-main, bottom);
      @include clear-border();
      padding: .2rem;
    }
    .content {
      padding: .2rem 0 0 .5rem;
      white-space: pre-wrap;
    }
  }
</style>
