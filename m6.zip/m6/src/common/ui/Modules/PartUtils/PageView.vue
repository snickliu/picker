<template>
  <div class="m-page-view">
    <div class="page arrow"
         :class="{'c-text-all c-bd': !disable.pre}"
         @click="turnPage('pre')">
      <i class="iconfont icon-arrow-left"></i>
    </div>
    <div class="page num c-bd c-text"
         :class="{'c-bg active': pageNum === num}"
         v-for="(num, index) in pageArr"
         :key="index"
         @click="selPage(num)">
      {{num}}
    </div>
    <div class="page arrow"
         :class="{'c-text-all c-bd': !disable.next}"
         @click="turnPage('next')">
      <i class="iconfont icon-arrow-right"></i>
    </div>
  </div>
</template>

<script>
const MAX_LENGTH = 5
export default {
  name: '',

  model: {
    prop: 'pageNum',
    event: 'changePageNum'
  },

  props: {
    pageNum: {
      type: Number,
      default: 1
    },
    totalPage: {
      type: Number,
      default: MAX_LENGTH
    }
  },

  components: {},

  data () {
    return {
      firstPage: this.pageNum,
      maxLength: MAX_LENGTH,
      middle: Math.floor(MAX_LENGTH / 2)
    }
  },

  computed: {
    length () {
      return this.totalPage < this.maxLength ? this.totalPage : this.maxLength
    },

    disable () {
      return {
        pre: this.pageNum <= 1,
        next: this.pageNum >= this.totalPage
      }
    },

    pageArr () {
      let initPage = this.firstPage

      if (this.firstPage < 1) {
        initPage = 1
      } else if (this.firstPage + this.length > this.totalPage) {
        initPage = this.totalPage + 1 - this.length
      }

      return new Array(this.length).fill(initPage).map(() => initPage++)
    }
  },

  created () {
  },

  methods: {
    selPage (num) {
      if (this.pageNum === num) {
        return
      }

      this.$emit('changePageNum', num)
    },

    turnPage (action) {
      if (this.disable[action]) {
        return
      }

      let num = this.pageNum
      if (action === 'next') {
        this.$emit('changePageNum', ++num)

        if (num > this.pageArr[this.pageArr.length - 1]) {
          this.firstPage = this.pageArr[this.pageArr.length - 1] - this.middle + 1
        }
      } else if (action === 'pre') {
        this.$emit('changePageNum', --num)

        if (num < this.pageArr[0]) {
          this.firstPage = num - (this.length - this.middle) + 1
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-page-view {
    @include border-1px($bd-main, top);
    @extend %u-flex-box;
    justify-content: center;
    border-radius: 0 0 .1rem .1rem;
    background-color: $white;
    // margin: 0 .2rem;
    padding: .28rem 0;
    overflow: hidden;
    .page {
      width: .68rem;
      height: .68rem;
      margin: 0 .08rem;
      text-align: center;
      line-height: .66rem;
      border-radius: .1rem;
      &.arrow {
        border: 1px solid $text-light;
      }
      &.num {
        font-size: .28rem;
        border: 1px solid;
        &.active {
          color: $white !important;
        }
      }
    }
  }
</style>
