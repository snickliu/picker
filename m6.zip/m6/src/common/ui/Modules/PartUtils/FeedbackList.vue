<template>
  <div class="m-feedback-list" v-if="commentList.length">
    <div class="item" v-for="(item, i) in commentList" :key="i">
      <p class="flipe" v-if="i === 2 && showFlipe" @click="showAllComment = !showAllComment">
        {{ showAllComment ? '收起评论' : `还有${item.count}条评论` }}
        <i class="iconfont" :class="showAllComment ? 'icon-collapae' : 'icon-dropdown'"></i>
      </p>
      <template v-else>
        <div class="u-post-auth">
          <BaseImage :defaultSrc="require('IMAGES/avatar.png')" :imgSrc="item.avatar"/>
          <div class="auth">
            <span class="name">{{item.replyUser}}<span class="reply">回复</span>{{item.beRepliedUser}}</span>
            <span class="date">{{getDateText(item.createTimeStamp).text}}</span>
          </div>
          <span class="level">{{item.level}}楼</span>
        </div>
        <pre class="content" v-html="item.content"></pre>
        <CommentBox
          type="level"
          :commentId="item.id"
          :isOwner="item.isOwner"
          :like="{count: item.upCount, isLike: item.isUp}"/>
      </template>
    </div>
  </div>
</template>

<script>
import CommentBox from './CommentBox.vue'
import getDateText from 'UTILS/getDateText'

export default {
  name: '',

  props: {
    list: {
      type: Array,
      default () {
        return []
      }
    }
  },

  components: {
    CommentBox
  },

  data () {
    return {
      showAllComment: false
    }
  },

  computed: {
    showFlipe () {
      return this.list.length > 3
    },

    commentList () {
      let length = this.list.length
      const list = this.list.map((item, index) => {
        return {
          ...item,
          level: index + 1
        }
      })

      if (length <= 3) {
        return list
      }

      let lastList = list.slice(-1)
      if (this.showAllComment) {
        lastList = list.slice(2)
      }

      return list.slice(0, 2).concat([{
        count: this.list.length - 3
      }], lastList)
    }
  },

  created () {
  },

  methods: {
    getDateText
  }
}
</script>

<style lang="scss">
  .m-feedback-list {
    background-color: $bg-main;
    margin-top: .3rem;
    .item {
      @include border-1px($bd-main, bottom);
      @include clear-border();
      padding: .2rem;
      .content {
        padding: .1rem 0 0 .5rem;
        white-space: pre-wrap;
      }
      .flipe {
        color: $text-sub;
        .iconfont {
          position: relative;
          top: .04rem;
          left: .04rem;
        }
      }
    }
  }
</style>
