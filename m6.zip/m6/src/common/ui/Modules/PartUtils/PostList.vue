<template>
  <div class="m-post-list">
    <div class="post" v-for="(item, index) in list" :key="index">
      <div class="header">
        <div class="issue" v-html="escapeTextToHtml(item.title)" @click="jumpToDetail(item.id)"></div>
        <div class="remark">
          <span class="u-comment" @click="markComment('up', item)">
            <i class="iconfont icon-thumbup" :class="{'c-text': item.isUp}"></i>
            {{item.upCount}}
          </span>
          <span class="u-comment" @click="markComment('down', item)">
            <i class="iconfont icon-thumbdown" :class="{'c-text': item.isDown}"></i>
            {{item.downCount}}
          </span>
          <span class="u-comment" @click="jumpToDetail(item.id, 'comment')">
            <i class="iconfont icon-comment"></i>
            {{item.commentCount}}
          </span>
        </div>
      </div>
      <div class="date">{{item.createTime}}</div>
      <div class="footer">
        <div class="auth">
          <BaseImage :defaultSrc="require('IMAGES/avatar.png')" :imgSrc="item.avatar"/>
          <span class="name">{{item.nickname}}</span>
        </div>
        <div class="read">
          <span class="u-comment"><i class="iconfont icon-eye"></i>{{item.viewCount}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import escapeTextToHtml from 'UTILS/escapeTextToHtml'

export default {
  name: '',

  props: {
    pageSize: {
      type: Number,
      default: 6
    },

    list: {
      type: Array,
      default () {
        return []
      }
    }
  },

  components: {},

  data () {
    return {}
  },

  created () {
  },

  methods: {
    escapeTextToHtml,

    markComment (action, item) {
      const isMark = `is${action.slice(0, 1).toUpperCase()}${action.slice(1)}`
      if (item[isMark]) {
        return
      }

      const count = item[`${action}Count`]
      this.$server.fetch(`${action}Post`, {
        postId: this.$route.query.postId
      }).then(() => {
        this.$set(item, isMark, 1)
        this.$set(item, `${action}Count`, count + 1)
      })
    },

    jumpToDetail (id, anchor = '') {
      this.$router.push({
        path: '/home/postDetail',
        query: {
          postId: id
        },
        hash: anchor
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-post-list {
    background-color: $white;
    border-radius: .1rem .1rem 0 0;
    .post {
      @include border-1px($bd-main, bottom);
      @include clear-border(last);
      padding: .16rem .2rem;
      .header {
        @extend %u-flex-box;
        .issue {
          @extend %u-flex-item;
          @include line-overflow();
          color: $post-issue;
          font-size: .3rem;
          line-height: .44rem;
          font-weight: bold;
          .title {
            color: $post-title;
          }
        }
      }
      .date {
        color: $text-assist;
        font-size: .2rem;
        margin: .1rem 0 .2rem 0;
      }
      .footer {
        @extend %u-flex-box;
        .auth {
          @extend %u-flex-item;
          .m-base-img {
            position: relative;
            top: .06rem;
            margin-right: .12rem;
            display: inline-block;
            width: .36rem;
            height: .36rem;
            border-radius: .1rem;
            overflow: hidden;
          }
          .name {
            font-size: .28rem;
            color: $post-issue;
          }
        }
      }
    }
  }
</style>
