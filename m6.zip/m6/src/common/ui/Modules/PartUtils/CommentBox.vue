<template>
  <div class="m-comment-box hide" :data-comment-box="type === 'normal' ? 'normal' : 'inside'">
    <div class="m-icons" v-if="type !== 'normal'">
      <span class="u-comment" v-if="isOwner" @click="delComment"><i class="iconfont icon-trash"></i>删除</span>
      <span class="u-comment"  @click="changeVisible"><i class="iconfont icon-comment"></i>回复</span>
      <span class="u-comment" v-if="type === 'level'" @click="setLike">
        <i class="iconfont" :class="likeComment.isLike ? 'c-text icon-like' : 'icon-like-line'"></i>
        顶 {{likeComment.count}}
      </span>
    </div>
    <div class="comment-box " v-if="commentSwitch" :class="type === 'normal' ? 'normal' : 'inside'">
      <div class="box">
      <textarea
        @focus="checkLogin"
        :class="{'c-bd': type !== 'normal'}"
        v-model="value"
        placeholder="请输入留言">
      </textarea>
      </div>
      <div class="utils">
        <span class="cancel" v-if="type !== 'normal'" @click="cancel">取消</span>
        <span class="empty"></span>
        <i class="iconfont icon-face" @click="emojiVisible = !emojiVisible"></i>
        <span class="btn c-bg" @click="publishComment">发布</span>
        <transition name="fade">
          <div class="emoji-list" v-show="emojiVisible">
          <span class="emoji"
                v-for="(emoji, index) in emojiList"
                :key="index"
                @click="chooseEmoji(emoji)">{{emoji}}</span>
          </div>
        </transition>
      </div>
    </div>
  </div>
</template>

<script>
import emojiList from 'UTILS/data/emojiList'
import { closest } from 'LIB'
import eventHub from 'LIB/eventHub'
import { mapGetters } from 'vuex'

export default {
  name: '',

  props: {
    type: {
      typs: String,
      default: 'normal'
    },
    commentId: {
      type: Number,
      default: 0
    },
    like: {
      type: Object,
      default () {
        return {
          count: 0,
          isLike: 0
        }
      }
    },
    isOwner: {
      type: Number,
      default: 0
    }
  },

  components: {},

  data () {
    return {
      isLike: 0,
      emojiList,
      value: '',
      emojiVisible: false
    }
  },

  computed: {
    ...mapGetters({
      commentData: 'commentData',
      siteConfig: 'siteConfig'
    }),

    postId () {
      return this.$route.query.postId || 0
    },
    commentSwitch () {
      return this.siteConfig.config && this.siteConfig.config.userCommentSwitch === '1'
    },
    likeComment () {
      return {
        count: this.like.count + this.isLike,
        isLike: (this.like.isLike || 0) + this.isLike
      }
    }
  },

  created () {
  },

  methods: {
    delComment () {
      this.$confirm('确定删除？').then(action => {
        if (action === 'ok') {
          this.$loading.show()
          this.$server.fetch('delComment', {
            commentId: this.commentId
          }).then(res => {
            eventHub.publish('fetchCommentData', [this.commentData.total.param, 'total'])
            eventHub.publish('fetchCommentData', [this.commentData.top.param, 'top'])
            this.$loading.hide()
          })
        }
      })
    },

    setLike () {
      if (this.likeComment.isLike) {
        return
      }

      this.$server.fetch('likeComment', {
        commentId: this.commentId
      }).then(() => {
        this.isLike = 1
      })
    },

    publishComment () {
      if (!this.value) {
        this.$toast('请输入留言/评论内容')
        return
      }

      this.$loading.show()
      this.$server.fetch('addComment', {
        content: this.value,
        postId: this.postId,
        commentId: this.commentId
      }).then(() => {
        this.value = ''
        if (this.type !== 'normal') {
          this.cancel()
        }
        eventHub.publish('fetchCommentData', [this.commentData.total.param, 'total'])
        eventHub.publish('fetchCommentData', [this.commentData.top.param, 'top'])
        this.$loading.hide()
        this.$toast('发布成功')
      }).catch(err => {
        this.$loading.hide()
        this.$toast(err.message)
      })
    },

    checkLogin () {
      eventHub.publish('checkLogin')
    },

    changeVisible (ev) {
      if (!this.commentSwitch) {
        this.$alert({
          message: '系统维护中，功能暂时关闭',
          okText: '确定'
        }).then(() => {
        })
        return
      }
      const target = closest(ev.target, '[data-comment-box=inside]')
      if (!target.classList.contains('hide')) {
        target.classList.add('hide')
        return
      }

      this.cancel()
      target.classList.remove('hide')
    },

    cancel () {
      const nodes = document.querySelectorAll('[data-comment-box=inside]')
      nodes.forEach(item => item.classList.add('hide'))
    },

    chooseEmoji (emoji) {
      this.checkLogin()
      this.emojiVisible = false

      if (this.$store.getters.isLogin) {
        this.value += emoji
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-comment-box {
    &.hide .inside {
      display: none !important;
    }
    .m-icons {
      text-align: right;
    }
    .comment-box {
      &.inside {
        margin-top: .3rem;
        padding: .04rem 0 .2rem 0;
        background-color: $bg-main;
        .box {
          margin: .2rem;
          textarea {
            height: 2rem;
            border: 1px solid;
            background-color: $white;
          }
        }
      }
      &.normal {
        .box {
          @include border-1px($bd-main, bottom);
          textarea {
            height: 2.8rem;
          }
        }
      }
      textarea {
        width: 100%;
        padding: .2rem .3rem;
        font-size: .28rem;
        border-radius: .1rem;
        line-height: .4rem;
        &::placeholder {
          color: $text-light;
        }
      }
      .utils {
        position: relative;
        @extend %u-flex-box;
        margin: .2rem;
        .cancel {
          color: $text-assist;
          padding: .1rem;
        }
        .empty {
          @extend %u-flex-item;
        }
        .iconfont {
          margin-right: .3rem;
          font-size: .5rem;
        }
        .btn {
          color: $white;
          width: 1.2rem;
          line-height: .6rem;
          text-align: center;
          border-radius: .1rem;
          font-size: .28rem;
        }
        .emoji-list {
          position: absolute;
          width: 5.2rem;
          height: 3rem;
          bottom: .96rem;
          padding: .1rem 0;
          padding-left: .16rem;
          background-color: $white;
          border-radius: .1rem;
          box-shadow: 0 .02rem .3rem rgba(130, 130, 130, .5);
          .emoji {
            font-size: .36rem;
            margin-left: .1rem;
          }
          &:after {
            content: '';
            position: absolute;
            bottom: -.56rem;
            right: .94rem;
            border: .28rem solid transparent;
            border-top-width: .32rem;
            border-top-color: $white;
          }
        }
      }
    }
  }
</style>
