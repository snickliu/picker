// A 导航栏
import Navbar01 from './Navbar/01.vue'

// B App下载
import Download01 from './Download/01.vue'

// C 文字广告位
import TextAd01 from './TextAd/01.vue'
import TextAd02 from './TextAd/02.vue'
import TextAd03 from './TextAd/03.vue'
import TextAd04 from './TextAd/04.vue'
import TextAd05 from './TextAd/05.vue'

// D 图片广告位
import ImageAd01 from './ImageAd/01.vue'
import ImageAd02 from './ImageAd/02.vue'
import ImageAd03 from './ImageAd/03.vue'

// E 帖子列表
import PostList01 from './PostList/01.vue'
import PostList02 from './PostList/02.vue'
import PostList03 from './PostList/03.vue'
import PostList04 from './PostList/04.vue'
import PostList05 from './PostList/05.vue'

// F 全量帖子列表 -- 暂时固定不变
import GlobalPost from './GlobalPost/Post.vue'

// G 全量评论列表 -- 暂时固定不变
import GlobalComment from './GlobalComment/Comment.vue'

// H 底部TAB栏
import HomeNav01 from './HomeNav/01.vue'

// I 搜索条
import Search01 from './Search/01.vue'

// J 开奖直播
import LotteryResult01 from './LotteryResult/01.vue'

const modulesObj = {
  // A
  'navigatBar_s01': Navbar01,
  // B
  'appDownLoad_s01': Download01,
  // C
  'textAd_s01': TextAd01,
  'textAd_s02': TextAd02,
  'textAd_s03': TextAd03,
  'textAd_s04': TextAd04,
  'textAd_s05': TextAd05,
  // D
  'imageAd_s01': ImageAd01,
  'imageAd_s02': ImageAd02,
  'imageAd_s03': ImageAd03,
  // E
  'topicList_s01': PostList01,
  'topicList_s02': PostList02,
  'topicList_s03': PostList03,
  'topicList_s04': PostList04,
  'topicList_s05': PostList05,
  // F
  'globalTopicList_s01': GlobalPost,
  // G
  'globalCommentList_s01': GlobalComment,
  // I
  'searchBar_s01': Search01,
  // J
  'lotteryLive_s01': LotteryResult01
}

const homeNavObj = {
  // H
  'H-01': HomeNav01
}

const getMap = (obj) => {
  const components = {}
  const map = {}
  Object.keys(obj).forEach((key, i) => {
    const name = `Module0${i + 1}`
    components[name] = obj[key]
    map[key] = name
  })

  return {
    components,
    map
  }
}

const modulesMap = getMap(modulesObj)
const homeNavMap = getMap(homeNavObj)

export {
  modulesMap,
  homeNavMap
}
