<template>
  <div class="m-post u-module-chunk" v-if="postList">
    <PostList :pageSize="pageSize" :list="postList"/>
    <PageView v-model="page" :totalPage="totalPage"/>
  </div>
</template>

<script>
import PostList from '../PartUtils/PostList.vue'
import PageView from '../PartUtils/PageView.vue'

export default {
  name: '',

  props: {
    pageSize: {
      type: Number,
      default: 6
    }
  },

  components: {
    PostList,
    PageView
  },

  data () {
    return {
      page: 1,
      postList: null,
      totalPage: 1
    }
  },

  created () {
    this.fetchPostList()
  },

  watch: {
    page: 'fetchPostList'
  },

  methods: {
    fetchPostList () {
      this.$server.fetch('postList', {
        page: this.page,
        size: this.pageSize
      }).then(res => {
        this.postList = res.list
        this.totalPage = res.totalPage
      })
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
