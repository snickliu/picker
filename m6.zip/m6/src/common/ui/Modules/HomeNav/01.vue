<template>
  <div class="m-home-nav">
    <footer class="nav-list">
      <template v-for="nav in navList">
        <router-link
          tag="div"
          :to="nav.type?nav.type:''"
          :key="nav.sort"
          class="nav"
          @click.native="moreVisible = false"
          v-if="nav.type !== 'more'">
          <i :class="`iconfont icon-${nav.type}`"></i>
          <p class="text">{{nav.text}}</p>
        </router-link>
        <div v-else class="nav" :key="nav.sort" :class="{rotate: moreVisible}" @click="tapMore">
          <div class="icon"><i :class="`c-text iconfont icon-${nav.type}`"></i></div>
          <p class="text">{{nav.text}}</p>
        </div>
      </template>
    </footer>

    <Popup v-if="hasMoreComponent" v-model="moreVisible" pos="bottom" class="more-dialog">
      <div class="site-list" v-if="more||linkList">
        <div class="item" v-for="(item,index) in (more||linkList)" :key="index" @click="jumpToSite(item.link)">{{item.text||item.siteName}}
        </div>
      </div>
    </Popup>
  </div>
</template>

<script>
import Popup from 'COMPONENTS/Popup'

export default {
  components: {
    Popup
  },

  props: {
    data: {
      type: Object,
      default () {
        return {}
      }
    }
  },

  data () {
    return {
      moreVisible: false,
      linkList: null,
      more: this.data.theMore
    }
  },

  computed: {
    navList () {
      const navList = this.data.list
      if (!navList) {
        return []
      }
      return navList
    },

    hasMoreComponent () {
      const arr = this.navList.filter(item => {
        return item.type === 'trend'
      })
      const hasMoreComponent = !!arr.length
      if (hasMoreComponent && !this.linkList && !this.more) {
        this.fetchLinkList()
      }

      return hasMoreComponent
    }
  },

  created () {
  },

  methods: {
    tapMore () {
      this.moreVisible = !this.moreVisible
    },

    fetchLinkList () {
      this.$server.fetch('linkList').then(res => {
        this.linkList = res
      })
    },

    jumpToSite (link) {
      this.moreVisible = false
      window.open(link)
    }
  }
}
</script>

<style lang="scss" scoped>
  .m-home-nav {

    .nav-list {
      @include border-1px($bg-main, top);
      @extend %u-flex-box;
      position: absolute;
      bottom: 0;
      width: 100%;
      height: .98rem;
      text-align: center;
      background-color: $bg-nav;
      .nav {
        @extend %u-flex-item;
        &.rotate {
          .iconfont {
            transform: rotate(225deg);
          }
        }
        .icon {
          position: relative;
          width: .46rem;
          height: .46rem;
          margin: auto;
          text-align: center;
          .iconfont {
            position: absolute;
            top: 0;
            left: 0;
            font-size: .46rem;
            transition: transform .3s;
          }
        }
        .iconfont {
          font-size: .4rem;
        }
        .text {
          color: $text-sub;
        }
      }
    }

    .more-dialog.m-popup {
      height: auto;
      bottom: .98rem;
      .site-list {
        max-height: 8.2rem;
        overflow: scroll;
        @extend %u-flex-box;
        background-color: $white;
        margin-bottom: .1rem;
        flex-wrap: wrap;
        justify-content: flex-start;
        .item {
          @include border-1px($bd-main, bottom);
          @include line-overflow(1);
          width: 25%;
          text-align: center;
          line-height: .68rem;
          padding: 0 .1rem;
          font-size: .26rem;
        }
      }
    }
  }
</style>
