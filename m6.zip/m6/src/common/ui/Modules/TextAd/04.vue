<template>
  <div class="m-text-ad-04 u-module-chunk">
    <p class="u-module-title c-text"><i class="str c-bg"></i>{{title.text}}</p>
    <div class="table">
      <router-link tag="div" class="item c-text" v-for="(item, i) in list" :key="i+100" :to="item.link">
        {{item.text}}
      </router-link>
      <div class="item" v-for="i in count" :key="i"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      title: this.data.titleList[0],
      list: this.data.contentList
    }
  },
  computed: {
    count () {
      if (!this.list.length) {
        return 0
      }

      return Math.ceil(this.list.length / 4) * 4 - this.list.length
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-text-ad-04 {
    .table {
      @extend %u-flex-box;
      flex-wrap: wrap;
      justify-content: space-between;
      text-align: center;
      font-size: .28rem;
      .item {
        @include border-1px($bd-main, bottom left);
        @include line-overflow();
        width: 25%;
        padding: .18rem 0;
        height: .7rem;
        &:nth-child(4n+1):after {
          border-left-color: $white;
        }
        &:nth-last-child(4):after,
        &:nth-last-child(3):after,
        &:nth-last-child(2):after,
        &:nth-last-child(1):after {
          border-bottom-color: $white;
        }
      }
    }
  }
</style>
