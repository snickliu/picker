<template>
  <div class="m-text-ad-03 u-module-chunk">
    <p class="title">{{title.text}}</p>
    <div class="list">
      <div class="item c-text" v-for="(item,i) in list" :key="i">
        <img class="u-icon-shake" src="~IMAGES/icons/new.png" alt="">
          <router-link class="c-text" :to="item.link">
            {{item.text}}
          </router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      title: this.data.titleList[0],
      list: this.data.contentList
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-text-ad-03 {
    text-align: center;
    .title {
      font-size: .32rem;
      color: $post-issue;
      font-weight: bold;
      padding: .24rem;
    }
    .list {
      padding: 0 .2rem;
      .item {
        text-align: left;
        font-size: .28rem;
        line-height: .6rem;
        margin-bottom: .3rem;
        border-radius: .1rem;
        box-shadow: 0 .2rem .34rem rgba(108, 108, 108, .4);
        .u-icon-shake {
          margin: 0 0.2rem 0 0.2rem;
        }
      }
    }
  }
</style>
