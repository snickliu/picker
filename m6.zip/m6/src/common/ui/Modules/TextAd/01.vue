<template>
  <div class="m-text-ad-01 u-module-chunk c-bg-light">
    <BaseImage :defaultSrc="require('IMAGES/default/textad01.png')" :imgSrc="imgUrl.pic"/>
    <div class="list">
    <p class="item c-bd" v-for="(item,i) in list" :key="i">{{item.text}}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      imgUrl: this.data.picList[0],
      list: this.data.contentList
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-text-ad-01 {
    position: relative;
    .list {
      position: relative;
      z-index: 2;
      .item {
        border-bottom: 1px solid;
        padding: .14rem .3rem;
        font-size: .28rem;
        color: $text-sub;
        word-break: break-all;
        &:last-of-type {
          border: none;
        }
      }
    }
    .m-base-img {
      position: absolute;
      width: 2.76rem;
      height: 2.76rem;
      top: .5rem;
      right: .2rem;
      z-index: 1;
      border-radius: 50%;
      overflow: hidden;
      background-color: $bg-main;
    }
  }
</style>
