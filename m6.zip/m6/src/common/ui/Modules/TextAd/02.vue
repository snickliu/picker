<template>
  <div class="m-text-ad-02 u-module-chunk">
    <div class="line title c-text-all">
      <div class="issue">期数</div>
      <div class="item">特码推荐</div>
      <div class="item">平肖推荐</div>
    </div>
    <div class="line" v-for="(item,i) in list" :key="i">
      <div class="issue">{{item.periodsNum}}</div>
      <div class="item">{{item.specialCode}}</div>
      <div class="item">{{item.zodiac}}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',

  components: {},
  props: {
    data: Object,
    default () {
      return {}
    }
  },
  data () {
    return {
      list: this.data.list
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-text-ad-02 {
    .line {
      @extend %u-flex-box;
      text-align: center;
      &:last-child .issue:after, &:last-child .item:after {
        border-bottom-color: $white;
      }
      &.title {
        font-size: .26rem;
      }
      .issue {
        @include border-1px($bd-main, bottom);
        @include line-overflow();
        width: 20%;
        padding: .18rem .12rem;
      }
      .item {
        @include border-1px($bd-main, bottom left);
        @extend %u-flex-item;
        padding: .18rem .12rem;
      }
    }
  }
</style>
