<template>
  <header class="g-header c-bg">
    <div class="aside left" @click="tapLeft">
      <slot name="left">
        <i v-if="leftIcon" :class="`fs-38 iconfont icon-${leftIcon}`"></i>
        <span v-if="leftText" class="fs-30">{{leftText}}</span>
      </slot>
    </div>
    <div class="middle">
      <slot><h1 class="fs-32" v-if="title">{{title}}</h1></slot>
    </div>
    <div class="aside right" @click="tapRight">
      <slot name="right">
        <span v-if="rightText">{{rightText}}</span>
        <i v-if="rightIcon" :class="`fs-30 iconfont icon-${rightIcon}`"></i>
      </slot>
    </div>
  </header>
</template>

<script>
export default {
  name: 'Header',

  components: {},

  props: {
    leftIcon: String,
    leftText: String,
    rightText: String,
    rightIcon: String,
    title: {
      type: String,
      default: ''
    },
    leftBack: {
      type: Boolean,
      default: true
    },
    rightRouter: Object
  },

  data () {
    return {}
  },

  created () {
  },

  methods: {
    tapLeft () {
      if (this.leftBack) {
        this.$router.goBack()
      }
      this.$emit('tapLeft')
    },

    tapRight () {
      if (this.rightRouter) {
        this.$router.push(this.rightRouter)
      }
      this.$emit('tapRight')
    }
  }
}
</script>

<style lang="scss" scoped>
  .g-header {
    position: relative;
    min-height: .88rem;
    text-align: center;
    color: $white;
    .iconfont {
      color: $white;
    }

    .aside {
      z-index: 100;
      @include set-center(v);
      &.left {
        left: .2rem;
      }
      &.right {
        right: .2rem;
        >span {
          display: inline-block;
          @include border-1px($white, all, solid, .04rem);
          padding: 0 .12rem;
          line-height: .44rem;
        }
      }
    }

    .middle {
      z-index: 10;
      width: 100%;
      text-align: center;
      @include set-center();
    }

  }
</style>
