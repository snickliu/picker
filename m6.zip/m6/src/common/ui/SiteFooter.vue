<template>
  <footer class="m-site-footer" :class="{'normal': !isTransparent, 'fix-bottom': fixBottom}" v-if="siteConfig">
    <p>{{siteConfig.config.webPowerBy}}</p>
    <p>{{siteConfig.config.webRecordNumber}}</p>
  </footer>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: '',

  props: {
    isTransparent: {
      type: Boolean,
      default: true
    },

    fixBottom: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    ...mapGetters([
      'siteConfig'
    ])
  },
  components: {},

  data () {
    return {
    }
  },

  created () {
  },

  methods: {}
}
</script>

<style lang="scss" scoped>
  .m-site-footer {
    height: 1rem;
    line-height: 0.5rem;
    text-align: center;
    color: $text-assist;
    &.normal {
      background-color: $bg-main;
    }
    &.fix-bottom {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
    }
  }
</style>
