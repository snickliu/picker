<template>
  <div id="app" :class="`theme-${themeType}`">
    <template v-if="inited">
      <keep-alive>
        <router-view v-if="$route.meta.keepAlive"/>
      </keep-alive>
      <router-view v-if="!$route.meta.keepAlive"/>
    </template>

    <div class="loading" v-else></div>
  </div>
</template>

<script>
import eventHub from 'LIB/eventHub'
import indexConfig from 'UTILS/data/indexConfig.js'

export default {
  data () {
    return {
      themeType: 'orange',
      inited: false
    }
  },

  created () {
    this.init()
    this.initEvent()
  },

  methods: {
    initEvent () {
      this.initRouterGoBack()
      this.checkLogin()
      this.fetchCommentData()
    },

    fetchCommentData () {
      eventHub.subscribe('fetchCommentData', ([param, type]) => {
        this.$server.fetch('commentList', param).then(res => {
          this.$store.commit(this.$mutationType.UPDATE_COMMENTDATA, {
            type,
            param,
            data: res
          })
        })
      })
    },

    checkLogin () {
      eventHub.subscribe('checkLogin', () => {
        if (!this.$store.getters.isLogin) {
          this.$confirm('请先登录').then(action => {
            if (action === 'ok') {
              this.$router.push({
                path: '/userCenter'
              })
            }
          })
        }
      })
    },

    initRouterGoBack () {
      eventHub.subscribe('goBack', () => {
        if (this.$store.getters.lastPageRecord[this.$route.name]) {
          this.$router.go(-1)
          return
        }
        this.$router.replace({
          name: this.$route.name.split('_')[0]
        })
      })
      this.$router.goBack = () => {
        eventHub.publish('goBack')
      }
    },

    init () {
      this.$loading.show()
      return Promise.all([
        this.$server.fetch('siteConfig'),
        this.$server.fetch('numberMap'),
        this.$server.fetch('homeConfiguration'),
        this.$server.fetch('dialogConfig')
      ]).then((res) => {
        // debugger // eslint-disable-line
        this.$loading.hide()
        this.inited = true
        // 奖底部导航抽出单独处理
        const homeNav = indexConfig.pop()
        // 开奖直播默认样式01，全量评论、全量帖子只有一种样式，暂时不会添加其它样式
        const siteConfig = {
          config: res[0], // siteConfig 各种开关配置
          homeNav,
          modules: res[2],
          dialogConfig: res[3] // 首页和帖子详情弹窗广告配置
        }
        this.$store.commit(this.$mutationType.UPDATE_SITECONFIG, siteConfig)
        this.$store.commit(this.$mutationType.UPDATE_NUMBERMAP, res[1])
        this.initConfig(res[0])
      }).catch(() => {
        this.$loading.hide()
        this.$store.commit(this.$mutationType.UPDATE_SITECONFIG, {})
        this.$store.commit(this.$mutationType.UPDATE_NUMBERMAP, {})
      })
    },
    // 初始化配置头部信息
    initConfig (data) {
    }
  }
}
</script>

<style lang="scss">
  @import "~STYLES/base.scss";

  @media screen and (min-width: 750px) {
    #app {
      width: 750px;
      @include set-center(h);
    }
  }
</style>
