const fs = require('fs')
const webpackConfig = require('./config/webpack')
const userConfig = require('./config')

let scssData = ''
userConfig.globalScss.forEach(file => {
  scssData += fs.readFileSync(file, 'utf-8')
})

const fusionDomain = 'https://test-cms.baifu-tech.net'

module.exports = {
  lintOnSave: 'error',
  productionSourceMap: false,

  css: {
    loaderOptions: {
      sass: {
        data: scssData
      }
    }
  },

  // 代理
  devServer: {
    proxy: {
      '/api': {
        target: fusionDomain,
        changeOrigin: true
      }
    }
  },

  chainWebpack: config => {
    webpackConfig.init(config)
  }
}
