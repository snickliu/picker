const fs = require('fs')
const childProcess = require('child_process')

const qiniuConf = {
  "src_dir": "./dist",
  "bucket": "sp-res",
  "overwrite": true,
  "rescan_local": true,
  "key_prefix": "m6/",
  "skip_suffixes": ".DS_Store,.exe",
  "skip_fixed_strings": ".svn,.git"
}

const CONFIG_FILENAME = 'qiniu.config.conf'

function deploy(type) {
  qiniuConf.key_prefix += type + '/'
  fs.writeFile(`./${CONFIG_FILENAME}`, JSON.stringify(qiniuConf), function (err) {
    if (!err) {
      console.log('==========================')
      console.log('七牛配置文件done')
      console.log('==========================')
      childProcess.execSync(`qshell qupload 50 ${CONFIG_FILENAME}`, {stdio: [0, 1, 2]})
    }
  })
}

module.exports = {
  deploy
}