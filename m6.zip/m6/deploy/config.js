module.exports = {
  deployTypes: ['test', 'release'],
  oss: {
    region: 'oss-cn-shenzhen',
    accessKeyId: 'LTAIkjlMJMFyr8sm',
    accessKeySecret: 'n2LOv19Q6i6LJN3pi9CMYpHjybxw40',
    bucket: 'cp-static-res'
  },
  ossDir: 'm6/',
  sourceDir: './dist'
}